// src/version.ts
var AGENT_VERSION = "0.2.5";
var AGENT_PROTOCOL_VERSION = "1";
var ATI_SELECTOR_CONFIG_VERSION = "dev-2";
var BUILD_CHANNEL = "dev";
var BUILD_DATE = true ? "2026-07-16T05:42:47.438Z" : "";
var COMMIT_SHA = "" ? "" : null;

// src/ati/atiUrls.ts
var ATI_LOADS_URL = "https://loads.ati.su/";
var ATI_HOST_MATCH_PATTERNS = [
  "https://loads.ati.su/*",
  "https://ati.su/*"
];
function isAtiHost(hostnameOrUrl) {
  if (!hostnameOrUrl) return false;
  let host = String(hostnameOrUrl).toLowerCase();
  if (host.includes("://")) {
    try {
      host = new URL(host).hostname.toLowerCase();
    } catch {
      return false;
    }
  }
  return host === "ati.su" || host === "loads.ati.su" || host.endsWith(".ati.su");
}

// src/build-info.ts
var BUILD_INFO = {
  agent_version: AGENT_VERSION,
  protocol_version: AGENT_PROTOCOL_VERSION,
  selector_config_version: ATI_SELECTOR_CONFIG_VERSION,
  build_channel: BUILD_CHANNEL,
  build_date: BUILD_DATE,
  commit_sha: COMMIT_SHA,
  browser_manifest_version: 3
};
function buildLoadedPayload() {
  return {
    agent_version: AGENT_VERSION,
    protocol_version: AGENT_PROTOCOL_VERSION,
    selector_config_version: ATI_SELECTOR_CONFIG_VERSION,
    build_channel: BUILD_CHANNEL,
    build_date: BUILD_DATE
  };
}

// src/sanitize.ts
var SENSITIVE_KEYS = /* @__PURE__ */ new Set([
  "agent_token",
  "token",
  "token_hash",
  "agent_token_hash",
  "pairing_code",
  "cookie",
  "cookies",
  "authorization",
  "auth_token",
  "bearer",
  "password",
  "pass",
  "pwd",
  "secret",
  "login",
  "username",
  "email",
  "phone",
  "tel",
  "localstorage",
  "session_cookie",
  "session_id_ati",
  "raw_html",
  "outer_html",
  "full_html",
  "contacts",
  "contact_list",
  "contact"
]);
var SENSITIVE_KEY_PATTERNS = [
  /token/i,
  /secret/i,
  /password/i,
  /cookie/i,
  /auth/i,
  /bearer/i,
  /pairing/i,
  /credential/i
];
function sanitizeUrl(u) {
  if (typeof u !== "string") return "";
  try {
    const url = new URL(u);
    return `${url.origin}${url.pathname}`;
  } catch {
    return "";
  }
}
function isSensitiveKey(key) {
  const k = key.toLowerCase();
  if (SENSITIVE_KEYS.has(k)) return true;
  return SENSITIVE_KEY_PATTERNS.some((r) => r.test(k));
}
function sanitizeAgentDiagnostics(input) {
  return _walk(input, 0);
}
function _walk(v, depth) {
  if (depth > 8) return "[depth_limit]";
  if (v === null || v === void 0) return v;
  if (Array.isArray(v)) return v.map((x) => _walk(x, depth + 1));
  if (typeof v === "object") {
    const out = {};
    for (const [k, val] of Object.entries(v)) {
      if (isSensitiveKey(k)) {
        out[k] = "[redacted]";
        continue;
      }
      if (/url$/i.test(k) && typeof val === "string") {
        out[k] = sanitizeUrl(val);
        continue;
      }
      out[k] = _walk(val, depth + 1);
    }
    return out;
  }
  if (typeof v === "string") {
    return v.length > 2e3 ? v.slice(0, 2e3) + "\u2026[truncated]" : v;
  }
  return v;
}

// ../src/lib/ai-dispatcher/orchestrator-transitions.ts
function normalizeRefreshIntervalSeconds(v) {
  const n = Number(v ?? 60);
  if (!Number.isFinite(n) || n < 60) return 60;
  if (n > 3600) return 3600;
  return Math.floor(n);
}

// src/search-scheduler.ts
var ALARM_PREFIX = "rt-search-refresh:";
var STORAGE_KEY = "rt_scheduled_tasks_v1";
var LOCK_KEY = "rt_scheduler_locks_v1";
async function readAll() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], (v) => resolve(v?.[STORAGE_KEY] ?? {}));
  });
}
async function writeAll(map) {
  return new Promise((resolve) => chrome.storage.local.set({ [STORAGE_KEY]: map }, () => resolve()));
}
async function readLocks() {
  return new Promise((resolve) => chrome.storage.local.get([LOCK_KEY], (v) => resolve(v?.[LOCK_KEY] ?? {})));
}
async function writeLocks(m) {
  return new Promise((resolve) => chrome.storage.local.set({ [LOCK_KEY]: m }, () => resolve()));
}
async function scheduleTaskRefresh(state) {
  const map = await readAll();
  const prev = map[state.searchTaskId] ?? {
    searchTaskId: state.searchTaskId,
    managedTabId: null,
    taskMode: "search",
    refreshIntervalSeconds: 60,
    nextRefreshAt: null,
    lastRefreshAt: null,
    enabled: true,
    orchestrationRunId: null,
    failureCount: 0,
    createdByAgent: false
  };
  const interval = normalizeRefreshIntervalSeconds(state.refreshIntervalSeconds ?? prev.refreshIntervalSeconds);
  const next = {
    ...prev,
    ...state,
    refreshIntervalSeconds: interval,
    nextRefreshAt: new Date(Date.now() + interval * 1e3).toISOString(),
    enabled: state.enabled ?? true
  };
  map[state.searchTaskId] = next;
  await writeAll(map);
  chrome.alarms.create(ALARM_PREFIX + state.searchTaskId, {
    delayInMinutes: interval / 60,
    periodInMinutes: interval / 60
  });
}
async function cancelTaskRefresh(searchTaskId) {
  const map = await readAll();
  delete map[searchTaskId];
  await writeAll(map);
  chrome.alarms.clear(ALARM_PREFIX + searchTaskId);
}
async function getScheduledTasks() {
  const map = await readAll();
  return Object.values(map);
}
async function lockTaskRefresh(searchTaskId, ttlMs = 9e4) {
  const locks = await readLocks();
  const now = Date.now();
  if (locks[searchTaskId] && locks[searchTaskId] > now) return false;
  locks[searchTaskId] = now + ttlMs;
  await writeLocks(locks);
  return true;
}
async function unlockTaskRefresh(searchTaskId) {
  const locks = await readLocks();
  delete locks[searchTaskId];
  await writeLocks(locks);
}
async function restoreActiveSearchSchedules() {
  const map = await readAll();
  for (const s of Object.values(map)) {
    if (!s.enabled) continue;
    const interval = normalizeRefreshIntervalSeconds(s.refreshIntervalSeconds);
    chrome.alarms.create(ALARM_PREFIX + s.searchTaskId, {
      delayInMinutes: interval / 60,
      periodInMinutes: interval / 60
    });
  }
}
function parseAlarmName(name) {
  return name.startsWith(ALARM_PREFIX) ? name.slice(ALARM_PREFIX.length) : null;
}

// src/shared/scheduler-state.mjs
var STOP_STATUSES = /* @__PURE__ */ new Set([
  "paused",
  "stopped",
  "failed",
  "confirmed",
  "deal_created",
  "suitable_found"
]);
var NO_MISSING_STATUSES = /* @__PURE__ */ new Set([
  "waiting_user_login",
  "extraction_failed",
  "opening_ati",
  "applying_filters",
  "starting_search"
]);
function normalizeRefreshIntervalSeconds2(v) {
  const n = Number(v ?? 60);
  if (!Number.isFinite(n) || n < 60) return 60;
  if (n > 3600) return 3600;
  return Math.floor(n);
}
function shouldStopScheduler(taskStatus) {
  if (!taskStatus) return true;
  return STOP_STATUSES.has(String(taskStatus));
}
function shouldRunScheduledRefresh({ taskStatus, autoRefreshEnabled }) {
  if (!autoRefreshEnabled) return false;
  return !shouldStopScheduler(taskStatus);
}
function shouldRunMissingLogic({ taskStatus, readSuccess, authenticated }) {
  if (!readSuccess) return false;
  if (!authenticated) return false;
  if (!taskStatus) return true;
  return !NO_MISSING_STATUSES.has(String(taskStatus));
}

// src/shared/filter-fingerprint.mjs
function canonicalize(v) {
  if (v == null) return null;
  if (Array.isArray(v)) return v.map(canonicalize).sort();
  if (typeof v === "object") {
    const out = {};
    for (const k of Object.keys(v).sort()) out[k] = canonicalize(v[k]);
    return out;
  }
  if (typeof v === "number") return Number(v.toFixed(6));
  if (typeof v === "string") return v.trim().toLowerCase();
  return v;
}
function computeFilterFingerprint(filters) {
  const s = JSON.stringify(canonicalize(filters ?? {}));
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = (h << 5) + h ^ s.charCodeAt(i);
  return (h >>> 0).toString(16);
}

// src/shared/full-scan-state.mjs
var STATES = Object.freeze({
  IDLE: "idle",
  SYNCING_FILTERS: "syncing_filters",
  SCANNING: "scanning",
  PAUSED: "paused",
  LOGIN_REQUIRED: "login_required",
  COMPLETING: "completing",
  COMPLETED: "completed",
  FAILED: "failed"
});
var EVENTS = Object.freeze({
  START: "START",
  // { taskId, fingerprint }
  SYNC_OK: "SYNC_OK",
  // { reset: bool }
  SYNC_FAIL: "SYNC_FAIL",
  // { error }
  PAGE_OK: "PAGE_OK",
  // { pagesRead }
  PAGE_LOOP: "PAGE_LOOP",
  // detected loop → completing(done)
  PAGE_MAX: "PAGE_MAX",
  // reached max_pages → completing(done)
  PAGE_FAIL: "PAGE_FAIL",
  // { error, retryable }
  PAUSE: "PAUSE",
  RESUME: "RESUME",
  LOGIN_REQUIRED: "LOGIN_REQUIRED",
  LOGIN_RESUMED: "LOGIN_RESUMED",
  COMPLETE_OK: "COMPLETE_OK",
  COMPLETE_FAIL: "COMPLETE_FAIL",
  // { error }
  ABORT: "ABORT"
  // reset to idle (task change/logout)
});
function initialState() {
  return {
    state: STATES.IDLE,
    taskId: null,
    filterFingerprint: null,
    pagesRead: 0,
    lastError: null,
    lastReason: null
  };
}
function fromServerStatus(serverStatus, taskId) {
  const s = serverStatus || {};
  const map = {
    pending: STATES.IDLE,
    reset: STATES.IDLE,
    running: STATES.SCANNING,
    done: STATES.COMPLETED,
    failed: STATES.FAILED
  };
  return {
    state: map[String(s.status)] ?? STATES.IDLE,
    taskId: taskId ?? null,
    filterFingerprint: s.filter_fingerprint ?? null,
    pagesRead: Number(s.pages_read ?? 0),
    lastError: s.error ?? null,
    lastReason: null
  };
}
function ignore(state, reason) {
  return { ...state, lastReason: reason };
}
function transition(state, event, payload = {}) {
  const cur = state.state;
  const evTaskId = payload.taskId ?? null;
  if (evTaskId && state.taskId && evTaskId !== state.taskId && event.type !== EVENTS.ABORT && event.type !== EVENTS.START) {
    return ignore(state, "task_id_mismatch");
  }
  switch (event.type) {
    case EVENTS.START: {
      const { taskId, fingerprint } = payload;
      if (!taskId) return ignore(state, "missing_task_id");
      if (state.taskId === taskId && (cur === STATES.SCANNING || cur === STATES.SYNCING_FILTERS || cur === STATES.COMPLETING)) {
        return ignore(state, "already_active");
      }
      if (state.taskId && state.taskId !== taskId && cur !== STATES.IDLE && cur !== STATES.COMPLETED && cur !== STATES.FAILED) {
        return ignore(state, "another_task_active");
      }
      const preservedFp = state.taskId === taskId ? state.filterFingerprint : null;
      const preservedPages = state.taskId === taskId ? state.pagesRead : 0;
      return {
        state: STATES.SYNCING_FILTERS,
        taskId,
        filterFingerprint: fingerprint ?? preservedFp,
        pagesRead: preservedPages,
        lastError: null,
        lastReason: null
      };
    }
    case EVENTS.SYNC_OK: {
      if (cur !== STATES.SYNCING_FILTERS) return ignore(state, "wrong_state_for_sync_ok");
      const reset = Boolean(payload.reset);
      return {
        ...state,
        state: STATES.SCANNING,
        pagesRead: reset ? 0 : state.pagesRead,
        lastReason: reset ? "filters_changed_reset" : "filters_unchanged"
      };
    }
    case EVENTS.SYNC_FAIL: {
      if (cur !== STATES.SYNCING_FILTERS) return ignore(state, "wrong_state_for_sync_fail");
      return { ...state, state: STATES.FAILED, lastError: payload.error ?? "sync_failed" };
    }
    case EVENTS.PAGE_OK: {
      if (cur !== STATES.SCANNING) return ignore(state, "not_scanning");
      return { ...state, pagesRead: Number(payload.pagesRead ?? state.pagesRead + 1), lastReason: "page_ok" };
    }
    case EVENTS.PAGE_LOOP:
    case EVENTS.PAGE_MAX: {
      if (cur !== STATES.SCANNING) return ignore(state, "not_scanning");
      return {
        ...state,
        state: STATES.COMPLETING,
        lastReason: event.type === EVENTS.PAGE_LOOP ? "loop_detected" : "max_pages"
      };
    }
    case EVENTS.PAGE_FAIL: {
      if (cur !== STATES.SCANNING) return ignore(state, "not_scanning");
      if (payload.retryable) return { ...state, lastReason: "page_retry", lastError: payload.error ?? null };
      return { ...state, state: STATES.FAILED, lastError: payload.error ?? "page_failed" };
    }
    case EVENTS.PAUSE: {
      if (cur === STATES.SCANNING || cur === STATES.SYNCING_FILTERS) {
        return { ...state, state: STATES.PAUSED, lastReason: "paused_by_user" };
      }
      return ignore(state, "cannot_pause");
    }
    case EVENTS.RESUME: {
      if (cur === STATES.PAUSED) return { ...state, state: STATES.SCANNING, lastReason: "resumed" };
      return ignore(state, "cannot_resume");
    }
    case EVENTS.LOGIN_REQUIRED: {
      if (cur === STATES.SCANNING || cur === STATES.SYNCING_FILTERS) {
        return { ...state, state: STATES.LOGIN_REQUIRED, lastReason: "ati_login_required" };
      }
      return ignore(state, "cannot_enter_login_required");
    }
    case EVENTS.LOGIN_RESUMED: {
      if (cur === STATES.LOGIN_REQUIRED) return { ...state, state: STATES.SCANNING, lastReason: "login_resumed" };
      return ignore(state, "cannot_resume_from_login");
    }
    case EVENTS.COMPLETE_OK: {
      if (cur !== STATES.COMPLETING && cur !== STATES.SCANNING) return ignore(state, "wrong_state_for_complete");
      return { ...state, state: STATES.COMPLETED, lastReason: state.lastReason ?? "complete_ok" };
    }
    case EVENTS.COMPLETE_FAIL: {
      return { ...state, state: STATES.FAILED, lastError: payload.error ?? "complete_failed" };
    }
    case EVENTS.ABORT: {
      return initialState();
    }
    default:
      return ignore(state, "unknown_event");
  }
}
function computeBackoffMs(attempt, { baseMs = 500, maxMs = 8e3 } = {}) {
  if (attempt <= 0) return 0;
  const v = Math.min(maxMs, baseMs * Math.pow(2, attempt - 1));
  return v;
}

// src/shared/full-scan-retry.mjs
function isRetryableStatus(status) {
  const s = Number(status);
  if (s === 0 || s === 408 || s === 429) return true;
  return s >= 500 && s < 600;
}
async function retryWithBackoff(attemptFn, opts = {}) {
  const maxAttempts = Math.max(1, opts.maxAttempts ?? 3);
  const baseMs = opts.baseMs ?? 500;
  const maxMs = opts.maxMs ?? 8e3;
  const sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
  const signal = opts.signal;
  let lastErr = null;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (signal?.aborted) throw new Error("aborted");
    let nonRetryable = false;
    try {
      const res = await attemptFn(attempt);
      if (res && typeof res === "object" && "status" in res) {
        if (res.status >= 200 && res.status < 300) return res.body;
        lastErr = new Error(`http_${res.status}`);
        if (!isRetryableStatus(res.status)) nonRetryable = true;
      } else {
        return res;
      }
    } catch (e) {
      if (e && e.message === "aborted") throw e;
      lastErr = e;
    }
    if (nonRetryable) break;
    if (attempt < maxAttempts) {
      await sleep(computeBackoffMs(attempt, { baseMs, maxMs }));
    }
  }
  throw lastErr ?? new Error("request_failed");
}
function computePageFingerprint(pageUrl, loadHashes) {
  const hashes = Array.from(loadHashes || []).filter((h2) => typeof h2 === "string" && h2.length > 0).sort();
  const s = `${pageUrl}|${hashes.join(",")}`;
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = (h << 5) + h ^ s.charCodeAt(i);
  return (h >>> 0).toString(16);
}

// src/full-scan/api.ts
var FullScanApi = class {
  fetchImpl;
  sleep;
  maxAttempts;
  baseBackoffMs;
  maxBackoffMs;
  constructor(opts) {
    this.fetchImpl = opts.fetchImpl;
    this.sleep = opts.sleep;
    this.maxAttempts = Math.max(1, opts.maxAttempts ?? 3);
    this.baseBackoffMs = opts.baseBackoffMs ?? 500;
    this.maxBackoffMs = opts.maxBackoffMs ?? 8e3;
  }
  request(method, path, body, signal) {
    return retryWithBackoff(async () => {
      const init = { method, signal };
      if (body !== null) {
        init.body = JSON.stringify(body);
        init.headers = { "content-type": "application/json" };
      }
      const res = await this.fetchImpl(path, init);
      let parsed;
      try {
        parsed = await res.json();
      } catch {
        parsed = {};
      }
      return { status: res.status, body: parsed };
    }, {
      maxAttempts: this.maxAttempts,
      baseMs: this.baseBackoffMs,
      maxMs: this.maxBackoffMs,
      sleep: this.sleep,
      signal
    });
  }
  syncFilters(taskId, fingerprint, signal) {
    return this.request(
      "POST",
      `/api/public/agent/ai-dispatcher/full-scan/sync-filters/${encodeURIComponent(taskId)}`,
      { filter_fingerprint: fingerprint },
      signal
    );
  }
  begin(taskId, signal) {
    return this.request(
      "POST",
      `/api/public/agent/ai-dispatcher/full-scan/begin/${encodeURIComponent(taskId)}`,
      {},
      signal
    );
  }
  submitPage(taskId, pageFingerprint, signal) {
    return this.request(
      "POST",
      `/api/public/agent/ai-dispatcher/full-scan/page/${encodeURIComponent(taskId)}`,
      { page_fingerprint: pageFingerprint },
      signal
    );
  }
  complete(taskId, status = "done", error, signal) {
    return this.request(
      "POST",
      `/api/public/agent/ai-dispatcher/full-scan/complete/${encodeURIComponent(taskId)}`,
      { status, error: error ?? null },
      signal
    );
  }
  getStatus(taskId, signal) {
    return this.request(
      "GET",
      `/api/public/agent/ai-dispatcher/full-scan/status/${encodeURIComponent(taskId)}`,
      null,
      signal
    );
  }
};

// src/full-scan/background-controller.mjs
var SNAPSHOT_KEY_DEFAULT = "rt_full_scan_v1";
function emptySnapshot() {
  return {
    taskId: null,
    state: STATES.IDLE,
    filterFingerprint: null,
    pagesRead: 0,
    lastPageFingerprint: null,
    nextExpectedPage: 1,
    updatedAt: (/* @__PURE__ */ new Date(0)).toISOString(),
    lastErrorCode: null,
    dispatcherId: null,
    sessionId: null
  };
}
function safeErrorCode(e) {
  const s = String(e && e.message || e || "error");
  const m = s.match(/http_\d+|[a-z][a-z0-9_]{2,31}/i);
  return m ? m[0].toLowerCase().slice(0, 40) : "error";
}
var FORBIDDEN_SNAPSHOT_KEYS = [
  "token",
  "agent_token",
  "password",
  "cookie",
  "authorization",
  "service_role",
  "supabase_key",
  "secret"
];
function assertNoSecrets(snapshot) {
  for (const k of Object.keys(snapshot || {})) {
    const lk = k.toLowerCase();
    for (const bad of FORBIDDEN_SNAPSHOT_KEYS) {
      if (lk.includes(bad)) {
        throw new Error(`snapshot_contains_secret_key:${k}`);
      }
    }
  }
}
var FullScanBackgroundController = class {
  /**
   * @param {object} deps
   * @param {object} deps.api          — { syncFilters, begin, submitPage, complete, getStatus }
   * @param {object} deps.storage      — { read(): snap|null, write(snap): void }
   * @param {() => string} [deps.now]
   */
  constructor(deps) {
    this.api = deps.api;
    this.storage = deps.storage;
    this.now = deps.now || (() => (/* @__PURE__ */ new Date()).toISOString());
    this._state = initialState();
    this._snapshot = emptySnapshot();
    this._chain = Promise.resolve();
    this._abort = null;
    this._restored = false;
  }
  getState() {
    return { ...this._state };
  }
  getSnapshot() {
    return { ...this._snapshot };
  }
  _ensureAbort() {
    if (!this._abort) this._abort = new AbortController();
    return this._abort.signal;
  }
  async _persist() {
    this._snapshot.updatedAt = this.now();
    assertNoSecrets(this._snapshot);
    await this.storage.write(this._snapshot);
  }
  _syncSnapshotFromState() {
    this._snapshot.taskId = this._state.taskId;
    this._snapshot.state = this._state.state;
    this._snapshot.pagesRead = this._state.pagesRead;
    this._snapshot.filterFingerprint = this._state.filterFingerprint;
    if (this._state.lastError) this._snapshot.lastErrorCode = this._state.lastError;
    this._snapshot.nextExpectedPage = this._state.pagesRead + 1;
  }
  // Все операции — через один mutex-цепочку, чтобы не было параллельных submitPage/complete.
  _run(fn) {
    const next = this._chain.then(fn, fn);
    this._chain = next.catch(() => void 0);
    return next;
  }
  async restore() {
    if (this._restored) return;
    this._restored = true;
    const snap = await this.storage.read().catch(() => null);
    if (!snap || !snap.taskId) return;
    this._snapshot = { ...emptySnapshot(), ...snap };
    if (snap.state === STATES.COMPLETED || snap.state === STATES.FAILED || snap.state === STATES.IDLE) {
      this._state = {
        ...initialState(),
        state: snap.state,
        taskId: snap.taskId,
        filterFingerprint: snap.filterFingerprint ?? null,
        pagesRead: Number(snap.pagesRead || 0)
      };
      return;
    }
    try {
      const status = await this.api.getStatus(snap.taskId);
      if (status && status.found !== false) {
        this._state = fromServerStatus({
          status: status.status,
          pages_read: status.pages_read,
          filter_fingerprint: status.filter_fingerprint,
          error: status.error
        }, snap.taskId);
        this._syncSnapshotFromState();
        await this._persist();
      }
    } catch {
    }
  }
  /**
   * Старт/пере-синхронизация: sync-filters + begin.
   * @returns {{ reset: boolean, state: string }}
   */
  startOrSyncFilters(taskId, fingerprint, identity) {
    return this._run(async () => {
      if (!taskId) throw new Error("missing_task_id");
      const cur = this._state;
      const busy = cur.taskId && cur.taskId !== taskId && cur.state !== STATES.IDLE && cur.state !== STATES.COMPLETED && cur.state !== STATES.FAILED;
      if (busy) throw new Error("another_task_active");
      if (this._abort) {
        this._abort.abort();
      }
      this._abort = new AbortController();
      const signal = this._abort.signal;
      if (cur.taskId !== taskId) {
        this._state = transition(initialState(), { type: EVENTS.START }, { taskId, fingerprint });
      } else {
        const s = transition(this._state, { type: EVENTS.START }, { taskId, fingerprint });
        if (s.state === STATES.SYNCING_FILTERS) this._state = s;
        else this._state = { ...this._state, filterFingerprint: fingerprint };
      }
      if (identity) {
        this._snapshot.dispatcherId = identity.dispatcherId ?? this._snapshot.dispatcherId ?? null;
        this._snapshot.sessionId = identity.sessionId ?? this._snapshot.sessionId ?? null;
      }
      let reset = false;
      try {
        const r = await this.api.syncFilters(taskId, fingerprint, signal);
        reset = Boolean(r && r.reset);
        this._state = transition(this._state, { type: EVENTS.SYNC_OK }, { taskId, reset });
      } catch (e) {
        this._state = transition(this._state, { type: EVENTS.SYNC_FAIL }, { taskId, error: safeErrorCode(e) });
        this._snapshot.lastErrorCode = safeErrorCode(e);
        this._syncSnapshotFromState();
        await this._persist();
        throw e;
      }
      try {
        await this.api.begin(taskId, signal);
      } catch (e) {
        this._snapshot.lastErrorCode = safeErrorCode(e);
      }
      this._syncSnapshotFromState();
      await this._persist();
      return { reset, state: this._state.state };
    });
  }
  /**
   * Отправка одной страницы (обязательно после startOrSyncFilters).
   * Возвращает { ok, reason?, pagesRead?, completed }.
   * completed=true если сервер сообщил loop_detected / max_pages и мы завершили.
   */
  submitPage(taskId, pageUrl, textHashes) {
    return this._run(async () => {
      if (!taskId) return { ok: false, reason: "missing_task_id", completed: false };
      if (!this._state.taskId || this._state.taskId !== taskId) {
        return { ok: false, reason: "task_id_mismatch", completed: false };
      }
      if (this._state.state === STATES.COMPLETED || this._state.state === STATES.FAILED) {
        return { ok: false, reason: "already_terminal", completed: true };
      }
      if (this._state.state !== STATES.SCANNING) {
        return { ok: false, reason: "not_started", completed: false };
      }
      const signal = this._ensureAbort();
      const fp = computePageFingerprint(pageUrl, textHashes);
      let r;
      try {
        r = await this.api.submitPage(taskId, fp, signal);
      } catch (e) {
        this._state = transition(
          this._state,
          { type: EVENTS.PAGE_FAIL },
          { taskId, error: safeErrorCode(e), retryable: true }
        );
        this._snapshot.lastErrorCode = safeErrorCode(e);
        this._syncSnapshotFromState();
        await this._persist();
        return { ok: false, reason: safeErrorCode(e), completed: false };
      }
      if (this._state.taskId !== taskId) {
        return { ok: false, reason: "task_id_mismatch", completed: false };
      }
      if (this._state.state !== STATES.SCANNING) {
        return { ok: false, reason: "already_terminal", completed: true };
      }
      if (r && r.ok) {
        this._state = transition(
          this._state,
          { type: EVENTS.PAGE_OK },
          { taskId, pagesRead: r.pages_read ?? this._state.pagesRead + 1 }
        );
        this._snapshot.lastPageFingerprint = fp;
        this._syncSnapshotFromState();
        await this._persist();
        return { ok: true, pagesRead: this._state.pagesRead, completed: false };
      }
      const reason = r && r.reason || "page_failed";
      if (reason === "loop_detected" || reason === "max_pages") {
        this._state = transition(this._state, {
          type: reason === "loop_detected" ? EVENTS.PAGE_LOOP : EVENTS.PAGE_MAX
        }, { taskId });
        this._syncSnapshotFromState();
        await this._completeInternal(taskId, "done", void 0, signal);
        return { ok: false, reason, pagesRead: r && r.pages_read, completed: true };
      }
      this._state = transition(
        this._state,
        { type: EVENTS.PAGE_FAIL },
        { taskId, error: reason, retryable: false }
      );
      this._snapshot.lastErrorCode = reason;
      this._syncSnapshotFromState();
      await this._persist();
      return { ok: false, reason, completed: false };
    });
  }
  async _completeInternal(taskId, status, error, signal) {
    if (this._state.state === STATES.COMPLETED || this._state.state === STATES.FAILED) return;
    try {
      await this.api.complete(taskId, status, error, signal);
      this._state = transition(this._state, {
        type: status === "done" ? EVENTS.COMPLETE_OK : EVENTS.COMPLETE_FAIL
      }, { taskId, error });
    } catch (e) {
      this._snapshot.lastErrorCode = safeErrorCode(e);
    }
    this._syncSnapshotFromState();
    await this._persist();
  }
  completeTask(taskId, status = "done", error) {
    return this._run(async () => {
      if (this._state.taskId !== taskId) return;
      const signal = this._ensureAbort();
      await this._completeInternal(taskId, status, error, signal);
    });
  }
  // stop() НЕ идёт через _run: мы должны отменить in-flight операцию,
  // а не ждать её завершения. In-flight submitPage/complete увидят
  // state.taskId === null и вернут task_id_mismatch (либо получат AbortError).
  async stop(reason) {
    if (this._abort) {
      try {
        this._abort.abort();
      } catch {
      }
      this._abort = null;
    }
    this._state = initialState();
    const prev = this._snapshot;
    this._snapshot = {
      ...emptySnapshot(),
      dispatcherId: prev.dispatcherId,
      sessionId: prev.sessionId,
      lastErrorCode: reason || null
    };
    await this._persist();
  }
};
function createChromeSnapshotStorage(key = SNAPSHOT_KEY_DEFAULT) {
  return {
    async read() {
      return new Promise((resolve) => {
        try {
          chrome.storage.local.get([key], (v) => {
            const raw = v && v[key];
            if (!raw) return resolve(null);
            try {
              resolve(JSON.parse(String(raw)));
            } catch {
              resolve(null);
            }
          });
        } catch {
          resolve(null);
        }
      });
    },
    async write(snap) {
      assertNoSecrets(snap || {});
      return new Promise((resolve) => {
        try {
          chrome.storage.local.set(
            { [key]: snap ? JSON.stringify(snap) : "" },
            () => resolve()
          );
        } catch {
          resolve();
        }
      });
    }
  };
}

// src/agent-origins.ts
var STATIC_ALLOWED = [
  "https://radius-track.ru",
  "https://www.radius-track.ru",
  "https://snuggle-db-bridge.lovable.app",
  "https://id-preview--d0d5cb47-0414-4a28-a4e9-a8beda3d2828.lovable.app"
];
var LOCALHOST_HOSTS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "0.0.0.0"]);
function normalizeOrigin(input) {
  if (!input) return null;
  try {
    const u = new URL(input);
    return `${u.protocol}//${u.host}`.toLowerCase();
  } catch {
    return null;
  }
}
function isTrustedAgentOrigin(input) {
  const origin = normalizeOrigin(input);
  if (!origin) return false;
  let u;
  try {
    u = new URL(origin);
  } catch {
    return false;
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") return false;
  if (LOCALHOST_HOSTS.has(u.hostname)) return true;
  if (u.protocol !== "https:") return false;
  return STATIC_ALLOWED.some((allowed) => normalizeOrigin(allowed) === origin);
}

// src/background.ts
var fullScanFetch = async (path, init) => {
  const s = await readStorage();
  if (!s[STORAGE_KEYS.baseUrl]) throw new Error("base_url_not_set");
  const headers = {
    ...init.headers ?? {}
  };
  if (s[STORAGE_KEYS.token]) headers.Authorization = `Bearer ${s[STORAGE_KEYS.token]}`;
  return fetch(`${s[STORAGE_KEYS.baseUrl]}${path}`, { ...init, headers });
};
var fullScanApi = new FullScanApi({ fetchImpl: fullScanFetch });
var fullScan = new FullScanBackgroundController({
  api: fullScanApi,
  storage: createChromeSnapshotStorage()
});
var STORAGE_KEYS = {
  baseUrl: "rt_base_url",
  token: "rt_agent_token",
  sessionId: "rt_session_id",
  lastHeartbeat: "rt_last_heartbeat",
  lastError: "rt_last_error",
  currentTaskId: "rt_current_task_id",
  lastVisibleCount: "rt_last_visible_count",
  lastSentCount: "rt_last_sent_count",
  lastSuitableCount: "rt_last_suitable_count",
  lastReadAt: "rt_last_read_at",
  waitingLogin: "rt_waiting_login_tasks_v1",
  nextRefreshAt: "rt_next_refresh_at"
};
async function readStorage() {
  const keys = Object.values(STORAGE_KEYS);
  return new Promise((resolve) => chrome.storage.local.get(keys, (v) => resolve(v)));
}
async function writeStorage(patch) {
  return new Promise((resolve) => chrome.storage.local.set(patch, () => resolve()));
}
async function readWaitingLogin() {
  return new Promise((r) => chrome.storage.local.get([STORAGE_KEYS.waitingLogin], (v) => {
    const raw = v?.[STORAGE_KEYS.waitingLogin];
    try {
      return r(raw ? JSON.parse(String(raw)) : {});
    } catch {
      return r({});
    }
  }));
}
async function writeWaitingLogin(map) {
  return new Promise((r) => chrome.storage.local.set(
    { [STORAGE_KEYS.waitingLogin]: JSON.stringify(map) },
    () => r()
  ));
}
async function upsertWaitingLogin(t) {
  const m = await readWaitingLogin();
  m[t.searchTaskId] = t;
  await writeWaitingLogin(m);
}
async function removeWaitingLogin(taskId) {
  const m = await readWaitingLogin();
  delete m[taskId];
  await writeWaitingLogin(m);
}
async function api(path, init) {
  const s = await readStorage();
  if (!s[STORAGE_KEYS.baseUrl]) throw new Error("base_url_not_set");
  const headers = { "content-type": "application/json" };
  if (s[STORAGE_KEYS.token]) headers.Authorization = `Bearer ${s[STORAGE_KEYS.token]}`;
  const res = await fetch(`${s[STORAGE_KEYS.baseUrl]}${path}`, { ...init, headers });
  if (!res.ok) throw new Error(`${res.status} ${await res.text().catch(() => "")}`);
  return res.json();
}
async function findAtiTab() {
  const tabs = await new Promise(
    (r) => chrome.tabs.query({ url: ATI_HOST_MATCH_PATTERNS }, (t) => r(t))
  );
  return tabs.find((t) => t.active) ?? tabs[0] ?? null;
}
async function sendToContent(tabId, message) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, message, (resp) => {
        const err = chrome.runtime?.lastError;
        if (err) return resolve(null);
        resolve(resp ?? null);
      });
    } catch {
      resolve(null);
    }
  });
}
async function heartbeat() {
  const tabs = await new Promise(
    (r) => chrome.tabs.query({ url: ATI_HOST_MATCH_PATTERNS }, (t) => r(t))
  );
  try {
    await api("/api/public/agent/ai-dispatcher/heartbeat", {
      method: "POST",
      body: JSON.stringify({
        agent_version: AGENT_VERSION,
        protocol_version: AGENT_PROTOCOL_VERSION,
        selector_config_version: ATI_SELECTOR_CONFIG_VERSION,
        build_channel: BUILD_CHANNEL,
        build_date: BUILD_DATE,
        browser_name: "Chrome",
        active_tab_count: tabs.length,
        status: "connected",
        last_action: "heartbeat"
      })
    });
    await writeStorage({ [STORAGE_KEYS.lastHeartbeat]: (/* @__PURE__ */ new Date()).toISOString(), [STORAGE_KEYS.lastError]: "" });
  } catch (e) {
    await writeStorage({ [STORAGE_KEYS.lastError]: String(e.message ?? e) });
  }
}
async function pollCommands() {
  try {
    const res = await api(
      "/api/public/agent/ai-dispatcher/commands/poll"
    );
    return res.commands ?? [];
  } catch {
    return [];
  }
}
async function ack(id) {
  await api(`/api/public/agent/ai-dispatcher/commands/${id}/ack`, { method: "POST", body: "{}" });
}
async function complete(id, result) {
  await api(`/api/public/agent/ai-dispatcher/commands/${id}/complete`, {
    method: "POST",
    body: JSON.stringify({ result_json: result })
  });
}
async function fail(id, error, outcome = "failed") {
  await api(`/api/public/agent/ai-dispatcher/commands/${id}/fail`, {
    method: "POST",
    body: JSON.stringify({ error_message: error, outcome })
  });
}
async function checkAtiAuth(tabId) {
  const res = await sendToContent(
    tabId,
    { type: "RT_DETECT_ATI_AUTH" }
  );
  const s = res?.status;
  if (s === "authenticated" || s === "login_required" || s === "unknown") return s;
  return "unknown";
}
var AUTH_REQUIRED_COMMANDS = /* @__PURE__ */ new Set([
  "apply_filters",
  "start_search",
  "read_visible_loads",
  "refresh_page"
]);
async function getSchedulerStatus(taskId) {
  try {
    return await api(`/api/public/agent/ai-dispatcher/tasks/${encodeURIComponent(taskId)}/scheduler-status`);
  } catch {
    return null;
  }
}
async function readAndSubmitVisibleLoads(taskId) {
  const tab = await findAtiTab();
  if (!tab?.id) throw new Error("no_ati_tab");
  const extracted = await sendToContent(
    tab.id,
    { type: "RT_READ_VISIBLE_LOADS" }
  );
  const data = await sendToContent(
    tab.id,
    { type: "RT_READ_VISIBLE_LOADS" }
  );
  const page = data?.page ?? extracted?.page;
  const loads = Array.isArray(data?.loads) ? data.loads : [];
  const visible = loads.length;
  let sent = 0;
  let suitable = 0;
  if (visible > 0 && page?.pageUrl) {
    const resp = await api("/api/public/agent/ai-dispatcher/loads", {
      method: "POST",
      body: JSON.stringify({ search_task_id: taskId, source_page_url: page.pageUrl, loads })
    });
    sent = (resp.created?.length ?? 0) + (resp.updated?.length ?? 0);
    suitable = resp.suitable_count ?? 0;
    const scores = [...resp.created ?? [], ...resp.updated ?? []];
    await sendToContent(tab.id, { type: "RT_HIGHLIGHT_LOADS", scores });
    await sendToContent(tab.id, { type: "RT_SHOW_OVERLAY", state: { sent, suitable, task_id: taskId } });
    const hashes = loads.map((l) => String(l?.agent_open_hint_json?.textHash ?? l?.source_external_ref ?? l?.raw_text ?? "")).filter((h) => h.length > 0);
    const pageRes = await fullScan.submitPage(taskId, page.pageUrl, hashes).catch(() => ({ ok: false, reason: "controller_error", completed: false }));
    if (pageRes.completed) {
      await api("/api/public/agent/ai-dispatcher/events", {
        method: "POST",
        body: JSON.stringify({ events: [{
          event_type: "initial_scan_completed",
          search_task_id: taskId,
          payload: { reason: pageRes.reason ?? null, pages_read: pageRes.pagesRead ?? null }
        }] })
      }).catch(() => void 0);
    }
  }
  await writeStorage({
    [STORAGE_KEYS.lastVisibleCount]: String(visible),
    [STORAGE_KEYS.lastSentCount]: String(sent),
    [STORAGE_KEYS.lastSuitableCount]: String(suitable),
    [STORAGE_KEYS.lastReadAt]: (/* @__PURE__ */ new Date()).toISOString()
  });
  return { visible, sent, suitable };
}
async function handleCommand(c) {
  await ack(c.id);
  if (c.search_task_id) await writeStorage({ [STORAGE_KEYS.currentTaskId]: c.search_task_id });
  const runId = String(c.command_payload_json?.orchestration_run_id ?? "") || null;
  try {
    if (AUTH_REQUIRED_COMMANDS.has(c.command_type)) {
      let tab = await findAtiTab();
      if (!tab?.id && c.command_type === "refresh_page") {
        throw new Error("no_ati_tab");
      }
      if (tab?.id) {
        const auth = await checkAtiAuth(tab.id);
        if (auth === "login_required") {
          if (c.search_task_id) {
            await upsertWaitingLogin({
              searchTaskId: c.search_task_id,
              orchestrationRunId: runId,
              managedTabId: tab.id,
              waitingSince: (/* @__PURE__ */ new Date()).toISOString(),
              lastAuthState: "login_required",
              loginDetectedSent: false,
              createdByAgent: true
            });
          }
          await fail(c.id, "ati_login_required", "login_required");
          return;
        }
        if (auth === "unknown") {
          await fail(c.id, "auth_state_unknown");
          return;
        }
      }
    }
    if (c.command_type === "open_ati") {
      const created = await chrome.tabs.create({ url: ATI_LOADS_URL, active: false });
      if (c.search_task_id && created?.id) {
        await upsertWaitingLogin({
          searchTaskId: c.search_task_id,
          orchestrationRunId: runId,
          managedTabId: created.id,
          waitingSince: (/* @__PURE__ */ new Date()).toISOString(),
          lastAuthState: "unknown",
          loginDetectedSent: false,
          createdByAgent: true
        });
      }
      await complete(c.id, { opened: true, tab_id: created?.id ?? null });
      return;
    }
    if (c.command_type === "refresh_page") {
      const tab = await findAtiTab();
      if (tab?.id) await chrome.tabs.reload(tab.id);
      if (tab?.id && c.search_task_id) {
        await new Promise((r2) => setTimeout(r2, 2500));
        const r = await readAndSubmitVisibleLoads(c.search_task_id);
        await complete(c.id, { reloaded: true, ...r });
        return;
      }
      await complete(c.id, { reloaded: Boolean(tab?.id) });
      return;
    }
    if (c.command_type === "read_visible_loads") {
      if (!c.search_task_id) throw new Error("missing_search_task_id");
      const r = await readAndSubmitVisibleLoads(c.search_task_id);
      await complete(c.id, r);
      if (r.sent > 0 || r.visible > 0) {
        const tab = await findAtiTab();
        await scheduleTaskRefresh({
          searchTaskId: c.search_task_id,
          managedTabId: tab?.id ?? null,
          taskMode: "search",
          refreshIntervalSeconds: 60,
          orchestrationRunId: runId,
          createdByAgent: true,
          enabled: true
        });
        await writeStorage({
          [STORAGE_KEYS.nextRefreshAt]: new Date(Date.now() + 6e4).toISOString()
        });
        await api("/api/public/agent/ai-dispatcher/events", {
          method: "POST",
          body: JSON.stringify({ events: [{
            event_type: "scheduler_started",
            search_task_id: c.search_task_id,
            payload: { interval_sec: 60, run_id: runId }
          }] })
        }).catch(() => void 0);
      }
      return;
    }
    if (c.command_type === "focus_candidate") {
      const tab = await findAtiTab();
      if (!tab?.id) throw new Error("no_ati_tab");
      const hint = c.command_payload_json ?? {};
      await sendToContent(tab.id, { type: "RT_FOCUS_LOAD", hint });
      await complete(c.id, { focused: true });
      return;
    }
    if (c.command_type === "close_candidate_page") {
      const tab = await findAtiTab();
      if (tab?.id) await sendToContent(tab.id, { type: "RT_CLEAR_HIGHLIGHTS" });
      await complete(c.id, { cleared: true });
      return;
    }
    if (c.command_type === "apply_filters") {
      const tab = await findAtiTab();
      if (!tab?.id) throw new Error("no_ati_tab");
      const payload = c.command_payload_json ?? {};
      const filters = payload.filters ?? payload;
      const res = await sendToContent(tab.id, { type: "RT_APPLY_FILTERS", filters });
      let filterReset = false;
      if (c.search_task_id && res?.ok) {
        try {
          const fp = computeFilterFingerprint(filters);
          const sync = await fullScan.startOrSyncFilters(c.search_task_id, fp, {
            sessionId: (await readStorage())[STORAGE_KEYS.sessionId] ?? null
          });
          filterReset = Boolean(sync?.reset);
        } catch {
        }
      }
      await complete(c.id, { applied: res?.ok ?? false, result: res?.result ?? null, filter_reset: filterReset });
      return;
    }
    if (c.command_type === "start_search") {
      await complete(c.id, { started: true });
      return;
    }
    if (c.command_type === "pause_search" || c.command_type === "stop_search") {
      if (c.search_task_id) await cancelTaskRefresh(c.search_task_id);
      if (c.command_type === "stop_search") {
        await fullScan.stop("stop_search").catch(() => void 0);
      }
      await complete(c.id, { paused: c.command_type === "pause_search", stopped: c.command_type === "stop_search" });
      return;
    }
    await complete(c.id, { noop: true, command_type: c.command_type });
  } catch (e) {
    await fail(c.id, String(e.message ?? e));
  }
}
async function tick() {
  const s = await readStorage();
  if (!s[STORAGE_KEYS.token]) return;
  await heartbeat();
  const cmds = await pollCommands();
  for (const c of cmds) await handleCommand(c).catch(() => void 0);
}
setInterval(() => {
  void tick();
}, 3e4);
async function handleScheduledRefresh(taskId) {
  const s = await readStorage();
  if (!s[STORAGE_KEYS.token]) {
    await cancelTaskRefresh(taskId);
    return;
  }
  const locked = await lockTaskRefresh(taskId);
  if (!locked) {
    await api("/api/public/agent/ai-dispatcher/events", {
      method: "POST",
      body: JSON.stringify({ events: [{ event_type: "refresh_skipped_locked", search_task_id: taskId }] })
    }).catch(() => void 0);
    return;
  }
  try {
    const status = await getSchedulerStatus(taskId);
    if (status?.should_stop_scheduler || shouldStopScheduler(status?.task_status)) {
      await cancelTaskRefresh(taskId);
      await api("/api/public/agent/ai-dispatcher/events", {
        method: "POST",
        body: JSON.stringify({ events: [{
          event_type: "scheduler_stopped",
          search_task_id: taskId,
          payload: { reason: status?.task_status ?? "unknown" }
        }] })
      }).catch(() => void 0);
      return;
    }
    if (!shouldRunScheduledRefresh({
      taskStatus: status?.task_status,
      autoRefreshEnabled: status?.auto_refresh_enabled ?? true
    })) return;
    let tab = await findAtiTab();
    if (!tab?.id) {
      const created = await chrome.tabs.create({ url: ATI_LOADS_URL, active: false });
      tab = created;
      await api("/api/public/agent/ai-dispatcher/events", {
        method: "POST",
        body: JSON.stringify({ events: [{
          event_type: "managed_tab_recreated",
          search_task_id: taskId,
          payload: { tab_id: created?.id ?? null }
        }] })
      }).catch(() => void 0);
      await new Promise((r) => setTimeout(r, 2500));
    }
    if (!tab?.id) return;
    const auth = await checkAtiAuth(tab.id);
    if (auth !== "authenticated") {
      if (auth === "login_required") {
        await upsertWaitingLogin({
          searchTaskId: taskId,
          orchestrationRunId: null,
          managedTabId: tab.id,
          waitingSince: (/* @__PURE__ */ new Date()).toISOString(),
          lastAuthState: "login_required",
          loginDetectedSent: false,
          createdByAgent: true
        });
        await api("/api/public/agent/ai-dispatcher/events", {
          method: "POST",
          body: JSON.stringify({ events: [{ event_type: "ati_login_required", search_task_id: taskId }] })
        }).catch(() => void 0);
      }
      return;
    }
    await api("/api/public/agent/ai-dispatcher/events", {
      method: "POST",
      body: JSON.stringify({ events: [{ event_type: "scheduled_refresh_started", search_task_id: taskId }] })
    }).catch(() => void 0);
    try {
      await chrome.tabs.reload(tab.id);
      await new Promise((r2) => setTimeout(r2, 2500));
      const r = await readAndSubmitVisibleLoads(taskId);
      if (shouldRunMissingLogic({ taskStatus: status?.task_status, readSuccess: true, authenticated: true })) {
      }
      await api("/api/public/agent/ai-dispatcher/events", {
        method: "POST",
        body: JSON.stringify({ events: [{
          event_type: "scheduled_refresh_completed",
          search_task_id: taskId,
          payload: { visible: r.visible, sent: r.sent, suitable: r.suitable }
        }] })
      }).catch(() => void 0);
      const interval = normalizeRefreshIntervalSeconds2(status?.refresh_interval_seconds ?? 60);
      await writeStorage({ [STORAGE_KEYS.nextRefreshAt]: new Date(Date.now() + interval * 1e3).toISOString() });
    } catch (e) {
      await api("/api/public/agent/ai-dispatcher/events", {
        method: "POST",
        body: JSON.stringify({ events: [{
          event_type: "scheduled_refresh_failed",
          search_task_id: taskId,
          payload: { error: String(e.message ?? e) }
        }] })
      }).catch(() => void 0);
    }
  } finally {
    await unlockTaskRefresh(taskId);
  }
}
try {
  chrome.alarms?.onAlarm.addListener((alarm) => {
    const taskId = parseAlarmName(alarm.name);
    if (!taskId) return;
    void handleScheduledRefresh(taskId);
  });
} catch {
}
async function processLoginDetected(waiting) {
  if (waiting.loginDetectedSent) return;
  const lockKey = `login_detected:${waiting.searchTaskId}`;
  const locked = await lockTaskRefresh(lockKey, 15e3);
  if (!locked) return;
  try {
    const resp = await api(
      "/api/public/agent/ai-dispatcher/login-detected",
      {
        method: "POST",
        body: JSON.stringify({
          search_task_id: waiting.searchTaskId,
          orchestration_run_id: waiting.orchestrationRunId,
          tab_id: waiting.managedTabId,
          detected_at: (/* @__PURE__ */ new Date()).toISOString()
        })
      }
    );
    if (resp?.ok) {
      waiting.loginDetectedSent = true;
      await upsertWaitingLogin(waiting);
      await removeWaitingLogin(waiting.searchTaskId);
    }
  } catch {
  } finally {
    await unlockTaskRefresh(lockKey);
  }
}
async function handleBridgeMessage(bridgeType, origin, payload) {
  if (!isTrustedAgentOrigin(origin)) {
    return { ok: false, error: "untrusted_origin" };
  }
  const s = await readStorage();
  if (bridgeType === "RT_AGENT_PING") {
    return {
      ok: true,
      data: {
        installed: true,
        connected: Boolean(s[STORAGE_KEYS.token]),
        agentVersion: AGENT_VERSION,
        protocolVersion: AGENT_PROTOCOL_VERSION
      }
    };
  }
  if (bridgeType === "RT_AGENT_STATUS") {
    const hasToken = Boolean(s[STORAGE_KEYS.token]);
    return {
      ok: true,
      data: {
        installed: true,
        connected: hasToken,
        agentVersion: AGENT_VERSION,
        protocolVersion: AGENT_PROTOCOL_VERSION,
        lastHeartbeatAt: s[STORAGE_KEYS.lastHeartbeat] ?? null,
        needsReconnect: !hasToken
      }
    };
  }
  if (bridgeType === "RT_AGENT_CONNECT_REQUEST") {
    const challengeId = String(payload?.challenge_id ?? "").trim();
    const challengeSecret = String(payload?.challenge_secret ?? "").trim();
    const reqOrigin = String(payload?.origin ?? origin).trim();
    if (!challengeId || !challengeSecret) {
      return { ok: false, error: "missing_challenge" };
    }
    if (!isTrustedAgentOrigin(reqOrigin) || reqOrigin !== origin) {
      return { ok: false, error: "untrusted_origin" };
    }
    try {
      const res = await fetch(`${reqOrigin}/api/public/agent/ai-dispatcher/pair-auto`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          challenge_id: challengeId,
          challenge_secret: challengeSecret,
          origin: reqOrigin,
          agent_version: AGENT_VERSION,
          protocol_version: AGENT_PROTOCOL_VERSION,
          browser_name: "Chrome"
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data?.agent_token) {
        return {
          ok: false,
          data: { installed: true, connected: false, errorCode: data?.error ?? "pair_failed" }
        };
      }
      await writeStorage({
        [STORAGE_KEYS.baseUrl]: reqOrigin,
        [STORAGE_KEYS.token]: data.agent_token,
        [STORAGE_KEYS.sessionId]: data.session_id
      });
      void heartbeat();
      return {
        ok: true,
        data: {
          installed: true,
          connected: true,
          sessionStatus: "connected",
          agentVersion: AGENT_VERSION
        }
      };
    } catch (e) {
      return { ok: false, error: String(e.message ?? e) };
    }
  }
  if (bridgeType === "RT_AGENT_DISCONNECT") {
    try {
      if (s[STORAGE_KEYS.baseUrl] && s[STORAGE_KEYS.token]) {
        await api("/api/public/agent/ai-dispatcher/events", {
          method: "POST",
          body: JSON.stringify({ events: [{ event_type: "agent_disconnected_by_user" }] })
        }).catch(() => void 0);
      }
    } finally {
      await writeStorage({
        [STORAGE_KEYS.token]: "",
        [STORAGE_KEYS.sessionId]: ""
      });
    }
    return { ok: true, data: { installed: true, connected: false } };
  }
  if (bridgeType === "RT_OPEN_ATI_AND_START") {
    const taskId = String(payload?.taskId ?? "").trim();
    if (!taskId) return { ok: false, error: "missing_task_id" };
    let tab = await findAtiTab();
    let reused = false;
    if (tab?.id && isAtiHost(tab.url ?? "")) {
      reused = true;
      try {
        await chrome.tabs.update(tab.id, { active: true });
        if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
      } catch {
      }
    } else {
      tab = await chrome.tabs.create({ url: ATI_LOADS_URL, active: true });
    }
    return {
      ok: true,
      data: {
        installed: true,
        connected: Boolean(s[STORAGE_KEYS.token]),
        tabId: tab?.id ?? null,
        url: ATI_LOADS_URL,
        reused
      }
    };
  }
  return { ok: false, error: "unknown_bridge_type" };
}
async function restoreOnStart() {
  const s = await readStorage();
  if (!s[STORAGE_KEYS.token] || !s[STORAGE_KEYS.baseUrl]) return;
  try {
    const res = await fetch(`${s[STORAGE_KEYS.baseUrl]}/api/public/agent/ai-dispatcher/session-health`, {
      headers: { Authorization: `Bearer ${s[STORAGE_KEYS.token]}` }
    });
    if (res.status === 401 || res.status === 404) {
      await writeStorage({ [STORAGE_KEYS.token]: "", [STORAGE_KEYS.sessionId]: "" });
      return;
    }
    const data = await res.json().catch(() => null);
    if (data?.token_status === "revoked" || data?.token_status === "expired") {
      await writeStorage({ [STORAGE_KEYS.token]: "", [STORAGE_KEYS.sessionId]: "" });
      return;
    }
    void heartbeat();
    await fullScan.restore().catch(() => void 0);
    try {
      await restoreActiveSearchSchedules();
      const tasks = await getScheduledTasks();
      await api("/api/public/agent/ai-dispatcher/events", {
        method: "POST",
        body: JSON.stringify({ events: [{
          event_type: "agent_state_restored",
          payload: { schedules: tasks.length }
        }] })
      }).catch(() => void 0);
      for (const t of tasks) {
        await api("/api/public/agent/ai-dispatcher/events", {
          method: "POST",
          body: JSON.stringify({ events: [{
            event_type: "scheduler_restored",
            search_task_id: t.searchTaskId
          }] })
        }).catch(() => void 0);
      }
    } catch {
    }
  } catch {
  }
}
try {
  chrome.runtime.onStartup?.addListener(() => {
    void restoreOnStart();
  });
  chrome.runtime.onInstalled?.addListener(() => {
    void restoreOnStart();
  });
} catch {
}
void restoreOnStart();
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg?.type === "RT_ATI_AUTH_STATE_CHANGED") {
        const senderTabId = sender?.tab?.id;
        if (msg.emitLoginDetected && senderTabId) {
          const map = await readWaitingLogin();
          const waiting = Object.values(map).find((w) => w.managedTabId === senderTabId) ?? Object.values(map)[0];
          if (waiting) await processLoginDetected(waiting);
        }
        if (msg.emitLoginRequired && senderTabId) {
          const map = await readWaitingLogin();
          const w = Object.values(map).find((x) => x.managedTabId === senderTabId);
          if (w) {
            w.lastAuthState = "login_required";
            await upsertWaitingLogin(w);
          }
        }
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "rt/bridge") {
        const senderOrigin = String(msg.origin ?? sender?.origin ?? sender?.url ?? "");
        const out = await handleBridgeMessage(
          String(msg.bridgeType ?? ""),
          senderOrigin,
          msg.payload ?? {}
        );
        sendResponse(out);
        return;
      }
      if (msg?.type === "rt/pair") {
        const res = await fetch(`${msg.baseUrl}/api/public/agent/ai-dispatcher/pair`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ pairing_code: msg.pairing_code, agent_version: AGENT_VERSION, protocol_version: AGENT_PROTOCOL_VERSION, browser_name: "Chrome" })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "pair_failed");
        await writeStorage({
          [STORAGE_KEYS.baseUrl]: msg.baseUrl,
          [STORAGE_KEYS.token]: data.agent_token,
          [STORAGE_KEYS.sessionId]: data.session_id
        });
        sendResponse({ ok: true, session_id: data.session_id });
        return;
      }
      if (msg?.type === "rt/status") {
        sendResponse(await readStorage());
        return;
      }
      if (msg?.type === "rt/disconnect") {
        await writeStorage({ [STORAGE_KEYS.token]: "", [STORAGE_KEYS.sessionId]: "" });
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "rt/read-current-page") {
        const s = await readStorage();
        const taskId = msg.search_task_id ?? s[STORAGE_KEYS.currentTaskId];
        if (!taskId) throw new Error("missing_search_task_id");
        const r = await readAndSubmitVisibleLoads(taskId);
        sendResponse({ ok: true, ...r });
        return;
      }
      if (msg?.type === "rt/show-overlay") {
        const tab = await findAtiTab();
        if (tab?.id) await sendToContent(tab.id, { type: "RT_SHOW_OVERLAY", state: {} });
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "rt/hide-overlay") {
        const tab = await findAtiTab();
        if (tab?.id) await sendToContent(tab.id, { type: "RT_HIDE_OVERLAY" });
        sendResponse({ ok: true });
        return;
      }
      if (msg?.type === "rt/diagnostics") {
        const tab = await findAtiTab();
        const raw = tab?.id ? await sendToContent(tab.id, { type: "RT_DIAGNOSTICS" }) : null;
        const diagnostics = sanitizeAgentDiagnostics({
          build_info: BUILD_INFO,
          page: raw?.diagnostics ?? null,
          has_ati_tab: Boolean(tab?.id)
        });
        sendResponse({ ok: true, diagnostics });
        return;
      }
      if (msg?.type === "rt/build-info") {
        sendResponse({ ok: true, build_info: BUILD_INFO });
        return;
      }
      if (msg?.type === "rt/session-health") {
        try {
          const data = await api("/api/public/agent/ai-dispatcher/session-health");
          sendResponse({ ok: true, data });
        } catch (e) {
          sendResponse({ ok: false, error: String(e.message ?? e) });
        }
        return;
      }
      if (msg?.type === "rt/add-to-call-queue") {
        if (!msg.candidate_id) throw new Error("missing_candidate_id");
        try {
          const r = await api(
            `/api/public/agent/ai-dispatcher/call-queue/${encodeURIComponent(msg.candidate_id)}`,
            { method: "POST", body: JSON.stringify({ source: "ati_page_button" }) }
          );
          sendResponse({ ok: true, already: Boolean(r?.already) });
        } catch (e) {
          sendResponse({ ok: false, error: String(e.message ?? e) });
        }
        return;
      }
      sendResponse({ error: "unknown_message" });
    } catch (e) {
      sendResponse({ error: String(e.message ?? e) });
    }
  })();
  return true;
});
(async () => {
  try {
    const s = await readStorage();
    if (!s[STORAGE_KEYS.token]) return;
    await api("/api/public/agent/ai-dispatcher/events", {
      method: "POST",
      body: JSON.stringify({
        events: [{
          event_type: "extension_build_loaded",
          payload: buildLoadedPayload(),
          message: `Browser Agent ${AGENT_VERSION} (${BUILD_CHANNEL})`
        }]
      })
    });
  } catch {
  }
})();
console.log(`[radius-track-agent] background loaded v${AGENT_VERSION} (protocol ${AGENT_PROTOCOL_VERSION}, build_date=${BUILD_DATE})`);
//# sourceMappingURL=background.js.map
