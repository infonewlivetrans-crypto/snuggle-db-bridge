// src/agent-origins.ts
var STATIC_ALLOWED = [
  "https://radius-track.ru",
  "https://www.radius-track.ru",
  "https://snuggle-db-bridge.lovable.app",
  "https://id-preview--d0d5cb47-0414-4a28-a4e9-a8beda3d2828.lovable.app"
];
var LOCALHOST_HOSTS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "0.0.0.0"]);
function normalizeOrigin(input) {
  if (!input) return null;
  try {
    const u = new URL(input);
    return `${u.protocol}//${u.host}`.toLowerCase();
  } catch {
    return null;
  }
}
function isTrustedAgentOrigin(input) {
  const origin = normalizeOrigin(input);
  if (!origin) return false;
  let u;
  try {
    u = new URL(origin);
  } catch {
    return false;
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") return false;
  if (LOCALHOST_HOSTS.has(u.hostname)) return true;
  if (u.protocol !== "https:") return false;
  return STATIC_ALLOWED.some((allowed) => normalizeOrigin(allowed) === origin);
}

// src/web-bridge.ts
var MSG_NS = "RT_BRIDGE";
var PAGE_ORIGIN = window.location.origin;
function isReq(x) {
  if (!x || typeof x !== "object") return false;
  const o = x;
  return o.ns === MSG_NS && o.dir === "web->ext" && typeof o.requestId === "string" && typeof o.nonce === "string" && typeof o.type === "string";
}
function respond(requestId, ok, data, error) {
  const resp = { ns: MSG_NS, dir: "ext->web", requestId, ok, data, error };
  window.postMessage(resp, PAGE_ORIGIN);
}
var ALLOWED_TYPES = /* @__PURE__ */ new Set([
  "RT_AGENT_PING",
  "RT_AGENT_STATUS",
  "RT_AGENT_CONNECT_REQUEST",
  "RT_AGENT_DISCONNECT",
  "RT_OPEN_ATI_AND_START"
]);
function sendToBackground(payload) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(payload, (resp) => {
        const err = chrome.runtime?.lastError;
        if (err) return resolve(null);
        resolve(resp ?? null);
      });
    } catch {
      resolve(null);
    }
  });
}
var FORBIDDEN_KEYS = /* @__PURE__ */ new Set([
  "agent_token",
  "token",
  "agent_token_hash",
  "token_hash",
  "pairing_code",
  "pairing_code_hash",
  "challenge_secret",
  "Authorization",
  "authorization",
  "cookie",
  "cookies",
  "password",
  "login"
]);
function sanitize(v) {
  if (!v || typeof v !== "object") return v;
  if (Array.isArray(v)) return v.map(sanitize);
  const out = {};
  for (const [k, val] of Object.entries(v)) {
    if (FORBIDDEN_KEYS.has(k)) continue;
    out[k] = sanitize(val);
  }
  return out;
}
window.addEventListener("message", async (ev) => {
  if (ev.source !== window) return;
  if (ev.origin !== PAGE_ORIGIN) return;
  if (!isTrustedAgentOrigin(ev.origin)) return;
  if (!isReq(ev.data)) return;
  const req = ev.data;
  if (!ALLOWED_TYPES.has(req.type)) return;
  try {
    const resp = await sendToBackground({
      type: "rt/bridge",
      bridgeType: req.type,
      requestId: req.requestId,
      nonce: req.nonce,
      origin: PAGE_ORIGIN,
      payload: req.payload ?? {}
    });
    if (!resp) {
      respond(req.requestId, false, { installed: true, connected: false }, "bridge_no_response");
      return;
    }
    respond(req.requestId, Boolean(resp.ok), sanitize(resp.data ?? resp), typeof resp.error === "string" ? resp.error : void 0);
  } catch (e) {
    respond(req.requestId, false, { installed: true }, String(e.message ?? e));
  }
});
try {
  window.postMessage(
    { ns: MSG_NS, dir: "ext->web", requestId: "bridge-ready", ok: true, data: { installed: true } },
    PAGE_ORIGIN
  );
} catch {
}
//# sourceMappingURL=web-bridge.js.map
