// src/version.ts
var AGENT_VERSION = "0.2.1";
var AGENT_PROTOCOL_VERSION = "1";
var ATI_SELECTOR_CONFIG_VERSION = "dev-1";
var BUILD_CHANNEL = "dev";
var BUILD_DATE = true ? "2026-07-06T11:55:15.268Z" : "";

// src/version-contract.ts
var MINIMUM_AGENT_VERSION = "0.1.0";
var RECOMMENDED_AGENT_VERSION = "0.2.0";
var SUPPORTED_SELECTOR_CONFIG_VERSIONS = ["dev-1"];
var AGENT_PROTOCOL_VERSION2 = "1";
function compareVersions(a, b) {
  const norm = (v) => v.replace(/^v/i, "").split(/[-+]/)[0].split(".").map((x) => {
    const n = parseInt(x, 10);
    return Number.isFinite(n) ? n : 0;
  });
  const A = norm(a);
  const B = norm(b);
  const len = Math.max(A.length, B.length);
  for (let i = 0; i < len; i++) {
    const x = A[i] ?? 0;
    const y = B[i] ?? 0;
    if (x < y) return -1;
    if (x > y) return 1;
  }
  return 0;
}
function getAgentCompatibilityStatus(input) {
  const reasons = [];
  const av = input.agent_version ?? null;
  const pv = input.protocol_version ?? null;
  const scv = input.selector_config_version ?? null;
  let status = "compatible";
  if (pv && String(pv) !== AGENT_PROTOCOL_VERSION2) {
    status = "protocol_mismatch";
    reasons.push(`protocol ${pv} \u2260 ${AGENT_PROTOCOL_VERSION2}`);
  } else if (!av || compareVersions(av, MINIMUM_AGENT_VERSION) < 0) {
    status = "unsupported";
    reasons.push(`agent ${av ?? "?"} < ${MINIMUM_AGENT_VERSION}`);
  } else if (compareVersions(av, RECOMMENDED_AGENT_VERSION) < 0) {
    status = "update_recommended";
    reasons.push(`recommended ${RECOMMENDED_AGENT_VERSION}`);
  } else if (scv && !SUPPORTED_SELECTOR_CONFIG_VERSIONS.includes(scv)) {
    status = "selector_config_warning";
    reasons.push(`selectors ${scv}?`);
  }
  return { status, reasons };
}

// src/popup.ts
var $ = (id) => document.getElementById(id);
async function send(msg) {
  return new Promise((r) => chrome.runtime.sendMessage(msg, (resp) => r(resp)));
}
function fmt(ts) {
  return ts ? new Date(ts).toLocaleTimeString() : "\u2014";
}
function validateBaseUrl(u) {
  if (!u) return { ok: false, reason: "empty" };
  if (!/^https?:\/\//i.test(u)) return { ok: false, reason: "must start with http(s)://" };
  if (/^(javascript|file|data):/i.test(u)) return { ok: false, reason: "unsafe scheme" };
  try {
    new URL(u);
    return { ok: true };
  } catch {
    return { ok: false, reason: "invalid URL" };
  }
}
$("verSub").textContent = `v${AGENT_VERSION} \xB7 protocol ${AGENT_PROTOCOL_VERSION} \xB7 ${BUILD_CHANNEL}`;
function renderMeta() {
  const compat = getAgentCompatibilityStatus({
    agent_version: AGENT_VERSION,
    protocol_version: AGENT_PROTOCOL_VERSION,
    selector_config_version: ATI_SELECTOR_CONFIG_VERSION
  });
  const labels = {
    compatible: "\u0412\u0435\u0440\u0441\u0438\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u044C\u043D\u0430",
    update_recommended: "\u0420\u0435\u043A\u043E\u043C\u0435\u043D\u0434\u0443\u0435\u0442\u0441\u044F \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C",
    unsupported: "\u0412\u0435\u0440\u0441\u0438\u044F \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F",
    protocol_mismatch: "\u041D\u0435\u0441\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430",
    selector_config_warning: "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440\u043E\u0432"
  };
  $("meta").innerHTML = [
    `agent_version: <b>${AGENT_VERSION}</b>`,
    `protocol: ${AGENT_PROTOCOL_VERSION} \xB7 selectors: ${ATI_SELECTOR_CONFIG_VERSION}`,
    `channel: ${BUILD_CHANNEL} \xB7 build_date: ${BUILD_DATE || "\u2014"}`,
    `min: ${MINIMUM_AGENT_VERSION} \xB7 \u0440\u0435\u043A\u043E\u043C\u0435\u043D\u0434.: ${RECOMMENDED_AGENT_VERSION}`,
    `<span class="compat-${compat.status}">\u0421\u043E\u0432\u043C\u0435\u0441\u0442\u0438\u043C\u043E\u0441\u0442\u044C: ${labels[compat.status]}</span>`
  ].join("<br/>");
}
async function refresh() {
  const s = await send({ type: "rt/status" });
  const connected = Boolean(s?.rt_agent_token);
  $("status").innerHTML = connected ? `<span class="ok">Paired \xB7 \u0442\u043E\u043A\u0435\u043D \u0430\u043A\u0442\u0438\u0432\u0435\u043D</span><br/>session: ${s.rt_session_id || "?"}<br/>heartbeat: ${fmt(s.rt_last_heartbeat)}${s.rt_last_error ? `<br/><span class="err">${s.rt_last_error}</span>` : ""}` : `<span class="muted">Not paired</span>`;
  const visible = s?.rt_last_visible_count ?? "\u2014";
  const sent = s?.rt_last_sent_count ?? "\u2014";
  const suitable = s?.rt_last_suitable_count ?? "\u2014";
  const at = s?.rt_last_read_at ? fmt(s.rt_last_read_at) : "\u2014";
  const task = s?.rt_current_task_id ?? "\u2014";
  $("live").innerHTML = `\u0417\u0430\u0434\u0430\u0447\u0430: ${task}<br/>\u0412\u0438\u0434\u043D\u043E: <b>${visible}</b> \xB7 \u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E: <b>${sent}</b> \xB7 \u041F\u043E\u0434\u0445\u043E\u0434\u0438\u0442: <b>${suitable}</b><br/>\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0435 \u0447\u0442\u0435\u043D\u0438\u0435: ${at}`;
  if (s?.rt_base_url) $("baseUrl").value = s.rt_base_url;
  renderMeta();
}
$("pair").addEventListener("click", async () => {
  const baseUrl = $("baseUrl").value.trim().replace(/\/$/, "");
  const code = $("code").value.trim();
  const v = validateBaseUrl(baseUrl);
  if (!v.ok) {
    alert("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u044B\u0439 URL \u0420\u0430\u0434\u0438\u0443\u0441 \u0422\u0440\u0435\u043A: " + v.reason);
    return;
  }
  if (!code) {
    alert("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 pairing-\u043A\u043E\u0434");
    return;
  }
  const res = await send({ type: "rt/pair", baseUrl, pairing_code: code });
  if (res?.ok) {
    $("code").value = "";
    refresh();
  } else alert("\u041E\u0448\u0438\u0431\u043A\u0430: " + (res?.error ?? "unknown"));
});
$("testConn").addEventListener("click", async () => {
  const baseUrl = $("baseUrl").value.trim().replace(/\/$/, "");
  const v = validateBaseUrl(baseUrl);
  if (!v.ok) {
    alert("URL: " + v.reason);
    return;
  }
  try {
    const r = await fetch(`${baseUrl}/api/public/agent/ai-dispatcher/health`);
    const data = await r.json().catch(() => ({}));
    alert(`Public health ${r.status}

` + JSON.stringify(data, null, 2));
  } catch (e) {
    alert("\u041E\u0448\u0438\u0431\u043A\u0430: " + e.message);
  }
});
$("openApp").addEventListener("click", async () => {
  const baseUrl = $("baseUrl").value.trim().replace(/\/$/, "");
  if (!validateBaseUrl(baseUrl).ok) return;
  chrome.tabs.create({ url: `${baseUrl}/dispatcher/ai-dispatcher` });
});
$("disconnect").addEventListener("click", async () => {
  await send({ type: "rt/disconnect" });
  refresh();
});
$("read").addEventListener("click", async () => {
  const res = await send({ type: "rt/read-current-page" });
  if (res?.ok) {
    refresh();
    alert(`\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043E: ${res.visible}. \u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E: ${res.sent}. \u041F\u043E\u0434\u0445\u043E\u0434\u0438\u0442: ${res.suitable}`);
  } else alert("\u041E\u0448\u0438\u0431\u043A\u0430: " + (res?.error ?? "unknown"));
});
$("diag").addEventListener("click", async () => {
  const res = await send({ type: "rt/diagnostics" });
  if (res?.diagnostics) {
    const txt = JSON.stringify(res.diagnostics, null, 2);
    alert("\u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 (\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u0430\u044F):\n\n" + txt.slice(0, 1200));
  } else alert("\u041E\u0448\u0438\u0431\u043A\u0430: " + (res?.error ?? "unknown"));
});
$("copyDiag").addEventListener("click", async () => {
  const res = await send({ type: "rt/diagnostics" });
  const txt = JSON.stringify(res?.diagnostics ?? {}, null, 2);
  try {
    await navigator.clipboard.writeText(txt);
    alert("\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E \u0432 \u0431\u0443\u0444\u0435\u0440");
  } catch {
    alert("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C");
  }
});
$("overlayOn").addEventListener("click", async () => {
  await send({ type: "rt/show-overlay" });
});
$("overlayOff").addEventListener("click", async () => {
  await send({ type: "rt/hide-overlay" });
});
$("mock").addEventListener("click", async () => {
  const res = await send({ type: "rt/send-mock-loads" });
  if (res?.ok) {
    refresh();
    alert(`\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E: ${res.sent}. \u041F\u043E\u0434\u0445\u043E\u0434\u0438\u0442: ${res.suitable}`);
  } else alert("\u041E\u0448\u0438\u0431\u043A\u0430: " + (res?.error ?? "unknown"));
});
refresh();
setInterval(refresh, 5e3);
//# sourceMappingURL=popup.js.map
