// src/ati/detectPage.ts
function detectPage() {
  const url = window.location.href;
  const host = window.location.hostname;
  const path = window.location.pathname;
  const isAtiPage = /(^|\.)ati\.su$/i.test(host);
  const isLoadsSearchPage = isAtiPage && /\/loads(\/|$|\?)/i.test(path);
  return {
    isAtiPage,
    isLoadsSearchPage,
    pageUrl: url,
    pageTitle: document.title || "",
    detectedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
}

// src/ati/atiSelectors.ts
var ATI_SELECTOR_CONFIG_VERSION = "dev-1";
var LOAD_ROW_SELECTORS = [
  '[data-testid*="loads-list-item"]',
  '[data-testid*="loads-list-row"]',
  '[class*="loads-list__row"]',
  '[class*="LoadsList__row"]',
  "tr[data-load-id]"
];
var LOAD_CARD_SELECTORS = [
  '[data-testid*="loads-card"]',
  '[data-testid="load-item"]',
  '[class*="loads-item"]',
  '[class*="load-card"]',
  'article[class*="load"]'
];
var LOAD_LINK_SELECTORS = [
  'a[href*="/loads/"]',
  'a[href*="/loadinfo/"]'
];
function pickAll(selectors, root = document) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const sel of selectors) {
    let list;
    try {
      list = root.querySelectorAll(sel);
    } catch {
      continue;
    }
    for (const el of Array.from(list)) {
      if (seen.has(el)) continue;
      seen.add(el);
      out.push(el);
    }
  }
  return out;
}

// src/ati/parseLoadText.ts
var CITY_ARROW = /([А-ЯЁ][а-яё]+(?:[\s\-][А-ЯЁа-яё]+)*)\s*[—–\->]{1,2}\s*([А-ЯЁ][а-яё]+(?:[\s\-][А-ЯЁа-яё]+)*)/;
var WEIGHT_RE = /(\d+(?:[.,]\d+)?)\s*т(?:онн)?(?![а-яё])/i;
var VOLUME_RE = /(\d+(?:[.,]\d+)?)\s*м[3³]/i;
var PRICE_RE = /(\d[\d\s]{2,})\s*(?:₽|руб|р\.?)/i;
var PPKM_RE = /(\d[\d\s.,]*)\s*(?:₽|руб|р\.?)\s*\/\s*км/i;
var DIST_RE = /(\d[\d\s]{1,})\s*км(?![а-яё])/i;
var DATE_RE = /\b(\d{1,2}[./-]\d{1,2}(?:[./-]\d{2,4})?)\b/;
var BODY_TYPES = ["\u0442\u0435\u043D\u0442", "\u0440\u0435\u0444", "\u0438\u0437\u043E\u0442\u0435\u0440\u043C", "\u0431\u043E\u0440\u0442", "\u0446\u0435\u043B\u044C\u043D\u043E\u043C\u0435\u0442", "\u0444\u0443\u0440\u0433\u043E\u043D", "\u043A\u043E\u043D\u0442\u0435\u0439\u043D\u0435\u0440", "\u0430\u0432\u0442\u043E\u0432\u043E\u0437"];
var LOAD_TYPES = ["\u0437\u0430\u0434\u043D\u044F\u044F", "\u0431\u043E\u043A\u043E\u0432\u0430\u044F", "\u0432\u0435\u0440\u0445\u043D\u044F\u044F", "\u043F\u043E\u043B\u043D\u0430\u044F", "\u0440\u0430\u0441\u0442\u0435\u043D\u0442\u043E\u0432\u043A\u0430", "\u0433\u0438\u0434\u0440\u043E\u0431\u043E\u0440\u0442"];
var PAY_TYPES = ["\u0431\u0435\u0437\u043D\u0430\u043B", "\u043F\u0440\u0435\u0434\u043E\u043F\u043B\u0430\u0442\u0430", "\u043D\u0430 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435", "\u043E\u0442\u0441\u0440\u043E\u0447\u043A\u0430", "\u0430\u0432\u0430\u043D\u0441", "\u043A\u0430\u0440\u0442\u0430", "\u043D\u0430\u043B"];
function num(s) {
  if (!s) return void 0;
  const n = Number(String(s).replace(/\s+/g, "").replace(",", "."));
  return Number.isFinite(n) ? n : void 0;
}
function parseLoadText(raw) {
  const text = (raw || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  if (!text) return {};
  const out = {};
  const route = text.match(CITY_ARROW);
  if (route) {
    out.pickup_city = route[1];
    out.delivery_city = route[2];
  }
  const w = text.match(WEIGHT_RE);
  if (w) out.weight = num(w[1]);
  const v = text.match(VOLUME_RE);
  if (v) out.volume = num(v[1]);
  const ppkm = text.match(PPKM_RE);
  if (ppkm) out.price_per_km = num(ppkm[1]);
  const price = text.match(PRICE_RE);
  if (price) out.price = num(price[1]);
  const dist = text.match(DIST_RE);
  if (dist) out.distance_km = num(dist[1]);
  const date = text.match(DATE_RE);
  if (date) out.pickup_date = date[1];
  const low = text.toLowerCase();
  for (const b of BODY_TYPES) if (low.includes(b)) {
    out.body_type = b;
    break;
  }
  for (const l of LOAD_TYPES) if (low.includes(l)) {
    out.loading_type = l;
    break;
  }
  for (const p of PAY_TYPES) if (low.includes(p)) {
    out.payment_type = p;
    break;
  }
  return out;
}
function hashText(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = (h << 5) + h ^ s.charCodeAt(i);
  return (h >>> 0).toString(16);
}

// src/ati/extractVisibleLoads.ts
function isVisible(el) {
  const r = el.getBoundingClientRect?.();
  if (!r) return false;
  if (r.width < 20 || r.height < 20) return false;
  const style = window.getComputedStyle(el);
  return style.visibility !== "hidden" && style.display !== "none";
}
function candidateElements() {
  let els = pickAll(LOAD_ROW_SELECTORS).filter(isVisible);
  if (els.length > 0) return { els, strategy: "rows" };
  els = pickAll(LOAD_CARD_SELECTORS).filter(isVisible);
  if (els.length > 0) return { els, strategy: "cards" };
  const linkEls = pickAll(LOAD_LINK_SELECTORS).filter(isVisible);
  const containers = /* @__PURE__ */ new Set();
  for (const a of linkEls) {
    const c = a.closest("article,li,tr,div");
    if (c) containers.add(c);
  }
  return { els: Array.from(containers), strategy: "link-fallback" };
}
function extractExternalRef(el) {
  const a = el.querySelector('a[href*="/loads/"], a[href*="/loadinfo/"]');
  if (a?.href) {
    const m = a.href.match(/loads?\/([^/?#]+)/i) || a.href.match(/loadinfo\/([^/?#]+)/i);
    if (m) return m[1];
  }
  const attr = el.getAttribute("data-load-id") ?? el.getAttribute("data-testid") ?? void 0;
  return attr ?? void 0;
}
function extractHref(el) {
  const a = el.querySelector('a[href*="/loads/"], a[href*="/loadinfo/"]');
  return a?.href ?? void 0;
}
function extractVisibleLoads() {
  const { els, strategy } = candidateElements();
  const loads = [];
  els.forEach((el, index) => {
    const raw = (el.textContent ?? "").replace(/\s+/g, " ").trim();
    if (!raw || raw.length < 8) return;
    const parsed = parseLoadText(raw);
    const externalRef = extractExternalRef(el);
    const href = extractHref(el);
    const textHash = hashText(raw.slice(0, 400));
    loads.push({
      ...parsed,
      raw_text: raw.slice(0, 600),
      source_row_index: index,
      source_external_ref: externalRef,
      source_card_anchor: el.id || void 0,
      source_url: href,
      agent_open_hint_json: {
        rowIndex: index,
        href,
        textHash,
        selector: strategy
      }
    });
  });
  return { loads, strategy };
}

// src/ati/highlightLoads.ts
var BADGE_CLASS = "rt-agent-badge";
var WRAP_ATTR = "data-rt-agent-highlighted";
function colorFor(score) {
  if (score == null) return { border: "#d1d5db", badgeBg: "#9ca3af", label: "?" };
  if (score >= 80) return { border: "#16a34a", badgeBg: "#16a34a", label: "\u041F\u043E\u0434\u0445\u043E\u0434\u0438\u0442" };
  if (score >= 60) return { border: "#eab308", badgeBg: "#ca8a04", label: "\u041C\u043E\u0436\u043D\u043E" };
  if (score >= 40) return { border: "#f97316", badgeBg: "#ea580c", label: "\u0420\u0438\u0441\u043A" };
  return { border: "#ef4444", badgeBg: "#dc2626", label: "\u041D\u0435 \u043F\u043E\u0434\u0445\u043E\u0434\u0438\u0442" };
}
function clearHighlights() {
  document.querySelectorAll(`[${WRAP_ATTR}]`).forEach((el) => {
    el.style.outline = "";
    el.style.outlineOffset = "";
    el.removeAttribute(WRAP_ATTR);
  });
  document.querySelectorAll(`.${BADGE_CLASS}`).forEach((el) => el.remove());
}
function allRowElements() {
  const rows = pickAll(LOAD_ROW_SELECTORS);
  if (rows.length) return rows;
  return pickAll(LOAD_CARD_SELECTORS);
}
function applyHighlights(entries) {
  clearHighlights();
  const rows = allRowElements();
  let applied = 0;
  for (const entry of entries) {
    const idx = entry.source_row_index;
    if (idx == null || idx < 0 || idx >= rows.length) continue;
    const el = rows[idx];
    const { border, badgeBg, label } = colorFor(entry.match_score);
    el.style.outline = `2px solid ${border}`;
    el.style.outlineOffset = "-2px";
    el.setAttribute(WRAP_ATTR, "1");
    const badge = document.createElement("div");
    badge.className = BADGE_CLASS;
    badge.textContent = `\u0420\u0422 ${entry.match_score ?? "?"} \xB7 ${label}`;
    Object.assign(badge.style, {
      position: "absolute",
      zIndex: "2147483000",
      background: badgeBg,
      color: "#fff",
      font: "600 11px/1.2 system-ui, sans-serif",
      padding: "3px 6px",
      borderRadius: "6px",
      pointerEvents: "auto",
      cursor: "help",
      boxShadow: "0 1px 3px rgba(0,0,0,.15)"
    });
    if (getComputedStyle(el).position === "static") el.style.position = "relative";
    badge.style.top = "4px";
    badge.style.right = "4px";
    const warnings = Array.isArray(entry.ai_warnings) ? entry.ai_warnings.join("; ") : "";
    badge.title = warnings || `candidate: ${entry.candidate_id ?? "\u2014"}`;
    el.appendChild(badge);
    if (entry.candidate_id) {
      const callBtn = document.createElement("button");
      callBtn.textContent = "\u0412 \u0437\u0432\u043E\u043D\u043A\u0438";
      callBtn.dataset.rtCandidateId = entry.candidate_id;
      Object.assign(callBtn.style, {
        position: "absolute",
        top: "28px",
        right: "4px",
        zIndex: "2147483000",
        background: "#0f172a",
        color: "#fff",
        border: "0",
        borderRadius: "6px",
        padding: "3px 6px",
        font: "600 11px system-ui, sans-serif",
        cursor: "pointer"
      });
      callBtn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        callBtn.disabled = true;
        callBtn.textContent = "\u2026";
        try {
          chrome.runtime.sendMessage(
            { type: "rt/add-to-call-queue", candidate_id: entry.candidate_id },
            (resp) => {
              callBtn.disabled = false;
              if (resp?.ok) callBtn.textContent = resp.already ? "\u0423\u0436\u0435 \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u0438" : "\u0414\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u043E";
              else callBtn.textContent = "\u041E\u0448\u0438\u0431\u043A\u0430";
            }
          );
        } catch {
          callBtn.textContent = "\u041E\u0448\u0438\u0431\u043A\u0430";
          callBtn.disabled = false;
        }
      });
      el.appendChild(callBtn);
    }
    applied++;
  }
  return applied;
}

// src/ati/agentOverlay.ts
var OVERLAY_ID = "rt-agent-overlay";
function showOverlay(state = {}, onAction) {
  let root = document.getElementById(OVERLAY_ID);
  if (!root) {
    root = document.createElement("div");
    root.id = OVERLAY_ID;
    Object.assign(root.style, {
      position: "fixed",
      right: "16px",
      bottom: "16px",
      zIndex: "2147483600",
      background: "#0f172a",
      color: "#fff",
      font: "12px/1.4 system-ui, sans-serif",
      padding: "10px 12px",
      borderRadius: "10px",
      boxShadow: "0 6px 24px rgba(0,0,0,.25)",
      width: "260px"
    });
    document.documentElement.appendChild(root);
  }
  root.innerHTML = `
    <div style="font-weight:600;margin-bottom:6px">\u0420\u0430\u0434\u0438\u0443\u0441 \u0422\u0440\u0435\u043A \xB7 \u0430\u0433\u0435\u043D\u0442</div>
    <div style="opacity:.85;margin-bottom:6px">
      \u0427\u0438\u0442\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0432\u0438\u0434\u0438\u043C\u0443\u044E \u0432\u044B\u0434\u0430\u0447\u0443 \u043D\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u043E\u0439 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0435. API ATI \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F.
    </div>
    <div>\u0412\u0438\u0434\u043D\u043E \u0433\u0440\u0443\u0437\u043E\u0432: <b>${state.visible_count ?? "\u2014"}</b></div>
    <div>\u041E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043E: <b>${state.sent_count ?? "\u2014"}</b></div>
    <div>\u041F\u043E\u0434\u0445\u043E\u0434\u0438\u0442: <b>${state.suitable_count ?? "\u2014"}</b></div>
    <div style="opacity:.7;margin:6px 0 8px">\u0417\u0430\u0434\u0430\u0447\u0430: ${state.task_id ?? "\u2014"}</div>
    <div style="display:flex;gap:6px;flex-wrap:wrap">
      <button data-a="read" style="flex:1;background:#22c55e;color:#0f172a;border:0;border-radius:6px;padding:6px;font:600 11px system-ui;cursor:pointer">\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C</button>
      <button data-a="send" style="flex:1;background:#38bdf8;color:#0f172a;border:0;border-radius:6px;padding:6px;font:600 11px system-ui;cursor:pointer">\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C</button>
      <button data-a="hide" style="flex:0 0 auto;background:transparent;color:#fff;border:1px solid #334155;border-radius:6px;padding:6px 8px;font:600 11px system-ui;cursor:pointer">\u0421\u043A\u0440\u044B\u0442\u044C</button>
    </div>
  `;
  root.querySelectorAll("button[data-a]").forEach((b) => {
    b.addEventListener("click", () => onAction?.(b.dataset.a));
  });
}
function hideOverlay() {
  document.getElementById(OVERLAY_ID)?.remove();
}

// src/ati/formSelectors.ts
var FORM_FIELDS = [
  {
    field: "pickup_city",
    kind: "combo",
    selectors: ['input[name*="from" i]', 'input[aria-label*="\u043E\u0442\u043A\u0443\u0434\u0430" i]', 'input[placeholder*="\u043E\u0442\u043A\u0443\u0434\u0430" i]'],
    labelKeywords: ["\u043E\u0442\u043A\u0443\u0434\u0430", "\u043F\u043E\u0433\u0440\u0443\u0437\u043A\u0430", "from"]
  },
  {
    field: "pickup_radius_km",
    kind: "number",
    selectors: ['input[name*="from_radius" i]', 'input[aria-label*="\u0440\u0430\u0434\u0438\u0443\u0441 \u043F\u043E\u0433\u0440\u0443\u0437\u043A\u0438" i]'],
    labelKeywords: ["\u0440\u0430\u0434\u0438\u0443\u0441 \u043F\u043E\u0433\u0440\u0443\u0437\u043A\u0438"]
  },
  {
    field: "delivery_city",
    kind: "combo",
    selectors: ['input[name*="to" i]', 'input[aria-label*="\u043A\u0443\u0434\u0430" i]', 'input[placeholder*="\u043A\u0443\u0434\u0430" i]'],
    labelKeywords: ["\u043A\u0443\u0434\u0430", "\u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0430", "to"]
  },
  {
    field: "delivery_radius_km",
    kind: "number",
    selectors: ['input[name*="to_radius" i]', 'input[aria-label*="\u0440\u0430\u0434\u0438\u0443\u0441 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438" i]'],
    labelKeywords: ["\u0440\u0430\u0434\u0438\u0443\u0441 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438"]
  },
  {
    field: "distance_min_km",
    kind: "number",
    selectors: ['input[name*="distance_min" i]', 'input[aria-label*="\u043C\u0438\u043D" i][aria-label*="\u0440\u0430\u0441\u0441\u0442" i]'],
    labelKeywords: ["\u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0440\u0430\u0441\u0441\u0442\u043E\u044F\u043D\u0438\u0435"]
  },
  {
    field: "distance_max_km",
    kind: "number",
    selectors: ['input[name*="distance_max" i]', 'input[aria-label*="\u043C\u0430\u043A\u0441" i][aria-label*="\u0440\u0430\u0441\u0441\u0442" i]'],
    labelKeywords: ["\u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0440\u0430\u0441\u0441\u0442\u043E\u044F\u043D\u0438\u0435"]
  },
  {
    field: "weight",
    kind: "number",
    selectors: ['input[name*="weight" i]', 'input[aria-label*="\u0432\u0435\u0441" i]'],
    labelKeywords: ["\u0432\u0435\u0441", "\u0442\u043E\u043D\u043D"]
  },
  {
    field: "volume",
    kind: "number",
    selectors: ['input[name*="volume" i]', 'input[aria-label*="\u043E\u0431\u044A" i]'],
    labelKeywords: ["\u043E\u0431\u044A\u0451\u043C", "\u043E\u0431\u044A\u0435\u043C", "\u043C3"]
  },
  {
    field: "pickup_date",
    kind: "date",
    selectors: ['input[name*="date" i]', 'input[type="date"]', 'input[aria-label*="\u0434\u0430\u0442\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438" i]'],
    labelKeywords: ["\u0434\u0430\u0442\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438", "\u043F\u043E\u0433\u0440\u0443\u0437\u043A\u0430"]
  },
  {
    field: "body_type",
    kind: "combo",
    selectors: ['input[name*="body" i]', 'select[name*="body" i]', 'input[aria-label*="\u043A\u0443\u0437\u043E\u0432" i]'],
    labelKeywords: ["\u0442\u0438\u043F \u043A\u0443\u0437\u043E\u0432\u0430", "\u043A\u0443\u0437\u043E\u0432"]
  },
  {
    field: "loading_type",
    kind: "combo",
    selectors: ['input[name*="loading" i]', 'select[name*="loading" i]', 'input[aria-label*="\u0437\u0430\u0433\u0440\u0443\u0437\u043A" i]'],
    labelKeywords: ["\u0442\u0438\u043F \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438"]
  },
  {
    field: "payment_type",
    kind: "combo",
    selectors: ['input[name*="payment" i]', 'select[name*="payment" i]', 'input[aria-label*="\u043E\u043F\u043B\u0430\u0442" i]'],
    labelKeywords: ["\u0444\u043E\u0440\u043C\u0430 \u043E\u043F\u043B\u0430\u0442\u044B", "\u043E\u043F\u043B\u0430\u0442\u0430"]
  },
  {
    field: "price_min",
    kind: "number",
    selectors: ['input[name*="price_min" i]', 'input[aria-label*="\u043C\u0438\u043D" i][aria-label*="\u0441\u0442\u0430\u0432\u043A" i]'],
    labelKeywords: ["\u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0441\u0442\u0430\u0432\u043A\u0430", "\u043C\u0438\u043D. \u0441\u0442\u0430\u0432\u043A\u0430"]
  },
  {
    field: "price_per_km_min",
    kind: "number",
    selectors: ['input[name*="ppkm" i]', 'input[name*="price_per_km" i]', 'input[aria-label*="\u0437\u0430 \u043A\u043C" i]'],
    labelKeywords: ["\u0441\u0442\u0430\u0432\u043A\u0430 \u0437\u0430 \u043A\u043C", "\u0437\u0430 \u043A\u0438\u043B\u043E\u043C\u0435\u0442\u0440"]
  }
];
function findFieldElement(strategy, root = document) {
  for (const sel of strategy.selectors) {
    try {
      const el = root.querySelector(sel);
      if (el) return el;
    } catch {
    }
  }
  if (strategy.labelKeywords?.length) {
    const labels = Array.from(root.querySelectorAll("label"));
    for (const kw of strategy.labelKeywords) {
      const lk = kw.toLowerCase();
      const label = labels.find((l) => (l.textContent ?? "").toLowerCase().includes(lk));
      if (label) {
        const forId = label.getAttribute("for");
        if (forId) {
          const el2 = document.getElementById(forId);
          if (el2) return el2;
        }
        const el = label.querySelector("input,select,textarea");
        if (el) return el;
      }
    }
  }
  return null;
}

// src/ati/setInputValue.ts
function setInputValue(el, value) {
  try {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    const setter = desc?.set;
    if (setter) setter.call(el, value);
    else el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  } catch {
    return false;
  }
}

// src/ati/selectOption.ts
function selectNativeOption(sel, valueOrLabel) {
  const target = valueOrLabel.trim().toLowerCase();
  for (const opt of Array.from(sel.options)) {
    if (opt.value.toLowerCase() === target || opt.textContent?.trim().toLowerCase() === target) {
      sel.value = opt.value;
      sel.dispatchEvent(new Event("change", { bubbles: true }));
      sel.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
  }
  return false;
}
function selectComboOption(input, label) {
  setInputValue(input, label);
  const listRoot = document.querySelector('[role="listbox"], [class*="dropdown"], [class*="Suggest"]');
  if (!listRoot) return false;
  const options = listRoot.querySelectorAll('[role="option"], li, div');
  const target = label.trim().toLowerCase();
  for (const o of Array.from(options)) {
    if ((o.textContent ?? "").trim().toLowerCase().includes(target)) {
      o.click();
      return true;
    }
  }
  return false;
}

// src/ati/formDiagnostics.ts
function sanitizeUrl(u) {
  try {
    const url = new URL(u);
    return `${url.origin}${url.pathname}`;
  } catch {
    return "";
  }
}
function collectFormDiagnostics() {
  const errors = [];
  const forms = document.querySelectorAll("form");
  const found = [];
  const missing = [];
  for (const f of FORM_FIELDS) {
    try {
      const el = findFieldElement(f);
      if (el) found.push(f.field);
      else missing.push(f.field);
    } catch (e) {
      errors.push(`${f.field}: ${e.message}`);
    }
  }
  const inputs = Array.from(document.querySelectorAll("input,select,textarea")).slice(0, 50).map((el) => {
    const name = el.name || el.getAttribute("aria-label") || el.getAttribute("placeholder") || "";
    return `${el.tagName.toLowerCase()}[${name.slice(0, 40)}]`;
  });
  return {
    pageUrl: sanitizeUrl(window.location.href),
    selectorConfigVersion: ATI_SELECTOR_CONFIG_VERSION,
    hasForm: forms.length > 0,
    detectedFormCount: forms.length,
    detectedInputs: inputs,
    fieldsFound: found,
    fieldsMissing: missing,
    loadRowCandidates: document.querySelectorAll('[data-testid*="loads"], [class*="loads-list"], [class*="load-card"]').length,
    errors
  };
}

// src/ati/applySearchFilters.ts
function applyOne(strategy, value) {
  const el = findFieldElement(strategy);
  if (!el) return { ok: false, reason: "element_not_found" };
  const strValue = String(value ?? "").trim();
  if (!strValue) return { ok: false, reason: "empty_value" };
  try {
    if (el instanceof HTMLSelectElement) {
      return selectNativeOption(el, strValue) ? { ok: true } : { ok: false, reason: "option_not_found" };
    }
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      if (strategy.kind === "combo") {
        return selectComboOption(el, strValue) ? { ok: true } : setInputValue(el, strValue) ? { ok: true } : { ok: false, reason: "set_failed" };
      }
      return setInputValue(el, strValue) ? { ok: true } : { ok: false, reason: "set_failed" };
    }
    return { ok: false, reason: "unsupported_element" };
  } catch (e) {
    return { ok: false, reason: e.message };
  }
}
function applySearchFilters(filters) {
  const applied = [];
  const failed = [];
  const missing = [];
  for (const strat of FORM_FIELDS) {
    const v = filters[strat.field];
    if (v === void 0 || v === null || v === "") {
      missing.push(strat.field);
      continue;
    }
    const r = applyOne(strat, v);
    if (r.ok) applied.push(strat.field);
    else failed.push({ field: strat.field, reason: r.reason ?? "unknown" });
  }
  return {
    success: applied.length > 0 && failed.length === 0,
    appliedFields: applied,
    failedFields: failed,
    missingFields: missing,
    diagnostics: collectFormDiagnostics()
  };
}

// src/ati/detectAuthState.ts
var AUTH_SIGNALS = [
  "[data-qa='user-menu']",
  "[data-testid='user-menu']",
  ".user-menu",
  "a[href*='/logout']",
  "a[href*='/profile']"
];
var LOGIN_SIGNALS = [
  "form[action*='login']",
  "input[name='password']",
  "[data-qa='login-form']",
  "a[href*='/login']"
];
var LOGIN_PATH_PATTERN = /\/(login|auth|signin|passport)/i;
function documentSafe() {
  try {
    return typeof document !== "undefined" ? document : null;
  } catch {
    return null;
  }
}
function countMatches(doc, selectors) {
  let n = 0;
  for (const sel of selectors) {
    try {
      if (doc.querySelector(sel)) n++;
    } catch {
    }
  }
  return n;
}
function detectAtiAuthState(doc) {
  const d = doc ?? documentSafe();
  if (!d) return { status: "unknown", strategy: "no_document", confidence: 0 };
  const url = (d.location?.pathname ?? "") + (d.location?.search ?? "");
  const isLoginPath = LOGIN_PATH_PATTERN.test(url);
  const authHits = countMatches(d, AUTH_SIGNALS);
  const loginHits = countMatches(d, LOGIN_SIGNALS);
  if (isLoginPath && authHits === 0 && loginHits > 0) {
    return { status: "login_required", strategy: "login_path+form", confidence: 0.95 };
  }
  if (authHits >= 2) {
    return { status: "authenticated", strategy: "multi_auth_signals", confidence: 0.85 };
  }
  if (authHits >= 1 && loginHits === 0) {
    return { status: "authenticated", strategy: "auth_signal", confidence: 0.6 };
  }
  if (loginHits >= 2 && authHits === 0) {
    return { status: "login_required", strategy: "multi_login_signals", confidence: 0.8 };
  }
  if (loginHits >= 1 && authHits === 0 && isLoginPath) {
    return { status: "login_required", strategy: "single_login_signal", confidence: 0.55 };
  }
  return { status: "unknown", strategy: "insufficient_signals", confidence: 0.2 };
}

// src/shared/auth-state-transition.mjs
var KNOWN = /* @__PURE__ */ new Set(["unknown", "authenticated", "login_required"]);
function normalizeAuthState(value) {
  const v = String(value ?? "").toLowerCase();
  if (KNOWN.has(v)) return v;
  return "unknown";
}
function shouldEmitLoginRequired(previous, current) {
  const p = normalizeAuthState(previous);
  const c = normalizeAuthState(current);
  if (c !== "login_required") return false;
  return p === "authenticated" || p === "unknown";
}
function shouldEmitLoginDetected(previous, current) {
  const p = normalizeAuthState(previous);
  const c = normalizeAuthState(current);
  return p === "login_required" && c === "authenticated";
}

// src/content.ts
function send(msg) {
  try {
    chrome.runtime.sendMessage(msg);
  } catch {
  }
}
var lastAuthState = "unknown";
var authDebounceTimer = null;
function safePageUrl() {
  try {
    const u = new URL(location.href);
    return `${u.origin}${u.pathname}`;
  } catch {
    return "";
  }
}
function checkAuthAndEmit() {
  const det = detectAtiAuthState();
  const prev = lastAuthState;
  const curr = normalizeAuthState(det.status);
  if (curr === prev) return;
  const emitLogin = shouldEmitLoginRequired(prev, curr);
  const emitDetected = shouldEmitLoginDetected(prev, curr);
  lastAuthState = curr;
  if (!emitLogin && !emitDetected && curr === "unknown") return;
  send({
    type: "RT_ATI_AUTH_STATE_CHANGED",
    previousState: prev,
    currentState: curr,
    strategy: det.strategy ?? null,
    confidence: det.confidence ?? null,
    pageUrl: safePageUrl(),
    detectedAt: (/* @__PURE__ */ new Date()).toISOString(),
    emitLoginRequired: emitLogin,
    emitLoginDetected: emitDetected
  });
}
function scheduleAuthCheck() {
  if (authDebounceTimer) clearTimeout(authDebounceTimer);
  authDebounceTimer = setTimeout(() => {
    authDebounceTimer = null;
    checkAuthAndEmit();
  }, 700);
}
function handleRead() {
  const page = detectPage();
  if (!page.isAtiPage || !page.isLoadsSearchPage) {
    send({ type: "RT_PAGE_NOT_SUPPORTED", url: page.pageUrl });
    return;
  }
  try {
    const { loads } = extractVisibleLoads();
    send({ type: "RT_VISIBLE_LOADS_EXTRACTED", page, loads });
  } catch (e) {
    send({ type: "RT_EXTRACTION_FAILED", error: String(e.message ?? e) });
  }
}
function findRowByHint(hint) {
  const { loads } = extractVisibleLoads();
  if (hint.source_external_ref) {
    const i = loads.findIndex((l) => l.source_external_ref === hint.source_external_ref);
    if (i >= 0) return findByIndex(i, "external_ref");
  }
  if (hint.source_card_anchor) {
    const el = document.getElementById(String(hint.source_card_anchor));
    if (el) return { el, by: "anchor" };
  }
  if (hint.text_hash) {
    const i = loads.findIndex((l) => l.agent_open_hint_json?.textHash === hint.text_hash);
    if (i >= 0) return findByIndex(i, "text_hash");
  }
  if (typeof hint.source_row_index === "number") {
    return findByIndex(hint.source_row_index, "row_index");
  }
  return null;
}
function findByIndex(idx, by) {
  const { loads } = extractVisibleLoads();
  if (idx < 0 || idx >= loads.length) return null;
  const el = document.querySelectorAll("[data-rt-agent-highlighted]")[idx] ?? document.querySelectorAll('article,li,tr,div[class*="row"],div[class*="card"]')[idx];
  return el ? { el, by } : null;
}
function handleFocus(hint) {
  const found = findRowByHint(hint);
  if (!found) {
    send({ type: "RT_LOAD_FOCUSED", ok: false });
    return;
  }
  found.el.scrollIntoView({ behavior: "smooth", block: "center" });
  found.el.style.outline = "3px solid #22c55e";
  found.el.style.outlineOffset = "-3px";
  send({ type: "RT_LOAD_FOCUSED", ok: true, matched_by: found.by });
}
chrome.runtime.onMessage.addListener((msg, _s, respond) => {
  try {
    if (!msg || typeof msg !== "object") return;
    if (msg.type === "RT_DETECT_ATI_AUTH") {
      const det = detectAtiAuthState();
      lastAuthState = normalizeAuthState(det.status);
      respond({ ok: true, status: det.status, strategy: det.strategy, confidence: det.confidence });
      return;
    }
    switch (msg.type) {
      case "RT_READ_VISIBLE_LOADS":
        handleRead();
        respond({ ok: true });
        return;
      case "RT_HIGHLIGHT_LOADS": {
        const n = applyHighlights(msg.scores ?? []);
        respond({ ok: true, applied: n });
        return;
      }
      case "RT_CLEAR_HIGHLIGHTS":
        clearHighlights();
        respond({ ok: true });
        return;
      case "RT_FOCUS_LOAD":
        handleFocus(msg.hint ?? {});
        respond({ ok: true });
        return;
      case "RT_APPLY_FILTERS": {
        const r = applySearchFilters(msg.filters ?? {});
        respond({ ok: r.success, result: r });
        return;
      }
      case "RT_DIAGNOSTICS":
        respond({ ok: true, diagnostics: collectFormDiagnostics() });
        return;
      case "RT_SHOW_OVERLAY":
        showOverlay(
          {
            sent_count: msg.state?.sent,
            suitable_count: msg.state?.suitable,
            task_id: msg.state?.task_id ?? null
          },
          (a) => {
            if (a === "hide") {
              hideOverlay();
              return;
            }
            if (a === "read") handleRead();
            if (a === "send") handleRead();
          }
        );
        send({ type: "RT_OVERLAY_READY" });
        respond({ ok: true });
        return;
      case "RT_HIDE_OVERLAY":
        hideOverlay();
        respond({ ok: true });
        return;
    }
  } catch (e) {
    respond({ ok: false, error: String(e.message ?? e) });
  }
});
try {
  const page = detectPage();
  if (page.isLoadsSearchPage) showOverlay({ task_id: null });
  if (page.isAtiPage) {
    lastAuthState = normalizeAuthState(detectAtiAuthState().status);
    const observer = new MutationObserver(() => scheduleAuthCheck());
    observer.observe(document.documentElement, { childList: true, subtree: true });
    scheduleAuthCheck();
  }
} catch {
}
console.log("[radius-track-agent] content loaded");
//# sourceMappingURL=content.js.map
